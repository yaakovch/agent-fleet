#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_TRANSPORT_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_TRANSPORT_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/config.sh"
source "${WTMUX_REPO_ROOT}/lib/tailscale.sh"

WTMUX_LAST_PROBE_COMMAND=""
WTMUX_LAST_PROBE_OUTPUT=""
WTMUX_LAST_PROBE_STATUS=""
declare -Ag WTMUX_OPENED_TAILSCALE_AUTH_URLS=()

wtmux_extract_tailscale_auth_url() {
  local text="${1:-}"
  printf '%s\n' "$text" | grep -Eo 'https://login\.tailscale\.com/a/[^[:space:]]+' | head -n 1
}

wtmux_open_url() {
  local url="$1"

  if [[ -n "${WTMUX_OPEN_URL_COMMAND:-}" ]]; then
    "${WTMUX_OPEN_URL_COMMAND}" "$url" >/dev/null 2>&1
    return $?
  fi

  case "$(wtmux_detect_platform)" in
    wsl)
      if command -v cmd.exe >/dev/null 2>&1; then
        cmd.exe /C start "" "$url" >/dev/null 2>&1
        return $?
      fi
      ;;
    termux)
      if command -v termux-open-url >/dev/null 2>&1; then
        termux-open-url "$url" >/dev/null 2>&1
        return $?
      fi
      ;;
    *)
      if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$url" >/dev/null 2>&1
        return $?
      fi
      if command -v open >/dev/null 2>&1; then
        open "$url" >/dev/null 2>&1
        return $?
      fi
      ;;
  esac

  return 1
}

wtmux_handle_tailscale_auth_requirement() {
  local machine_id="$1"
  local output="$2"
  local auth_url=""

  auth_url="$(wtmux_extract_tailscale_auth_url "$output")"
  [[ -n "$auth_url" ]] || return 1

  wtmux_warn "tailscale ssh for ${machine_id} requires browser approval: ${auth_url}"
  if [[ -z "${WTMUX_OPENED_TAILSCALE_AUTH_URLS[$auth_url]:-}" ]]; then
    if wtmux_open_url "$auth_url"; then
      WTMUX_OPENED_TAILSCALE_AUTH_URLS["$auth_url"]=1
      wtmux_info "opened browser for tailscale ssh approval"
    else
      wtmux_warn "could not open browser automatically; visit the approval URL manually"
    fi
  fi

  return 0
}

wtmux_transport_for_machine() {
  local machine_id="$1"
  local local_machine=""
  local transport_value=""

  local_machine="$(wtmux_detect_local_machine_id 2>/dev/null || true)"
  if [[ -n "$local_machine" && "$machine_id" == "$local_machine" ]]; then
    printf '%s\n' "local"
    return 0
  fi

  transport_value="${WTMUX_FORCE_TRANSPORT:-$(wtmux_machine_field "$machine_id" "transport")}"
  printf '%s\n' "${transport_value:-tailscale}"
}

wtmux_machine_remote_target() {
  local machine_id="$1"
  local transport
  local user
  local host

  transport="$(wtmux_transport_for_machine "$machine_id")"
  user="$(wtmux_machine_field "$machine_id" "linux_username")"
  if [[ "$transport" == "ssh" ]]; then
    host="$(wtmux_machine_field "$machine_id" "fallback_ssh_host")"
    if [[ -z "$host" ]]; then
      host="$(wtmux_machine_field "$machine_id" "fallback_ip")"
    fi
  else
    host="$(wtmux_machine_field "$machine_id" "tailscale_node")"
  fi
  printf '%s@%s\n' "$user" "$host"
}

wtmux_machine_ssh_target() {
  local machine_id="$1"
  local transport
  local user
  local host
  local resolved_host=""

  transport="$(wtmux_transport_for_machine "$machine_id")"
  user="$(wtmux_machine_field "$machine_id" "linux_username")"

  if [[ "$transport" == "ssh" ]]; then
    host="$(wtmux_machine_field "$machine_id" "fallback_ssh_host")"
    if [[ -z "$host" ]]; then
      host="$(wtmux_machine_field "$machine_id" "fallback_ip")"
    fi
  else
    host="$(wtmux_machine_field "$machine_id" "tailscale_node")"
    resolved_host="$(wtmux_machine_field "$machine_id" "fallback_ip")"
    if [[ -n "$resolved_host" ]]; then
      host="$resolved_host"
    else
      resolved_host="$(wtmux_tailscale_peer_ip "$host" 2>/dev/null || true)"
      if [[ -n "$resolved_host" ]]; then
        host="$resolved_host"
      fi
    fi
  fi

  printf '%s@%s\n' "$user" "$host"
}

wtmux_build_ssh_command_internal() {
  local target_var="$1"
  local -n out_ref="$target_var"
  local machine_id="$2"
  local tty_mode="${3:-none}"
  shift 3
  local remote_target
  local identity_file
  local remote_shell
  local remote_command

  remote_target="$(wtmux_machine_ssh_target "$machine_id")"
  identity_file="$(wtmux_machine_field "$machine_id" "fallback_identity_file")"
  remote_shell="$(wtmux_shell_quote_join "$@")"
  printf -v remote_command 'bash -lc %q' "$remote_shell"

  out_ref=("ssh" "-o" "BatchMode=yes" "-o" "ConnectTimeout=5" "-o" "IdentitiesOnly=yes")
  if [[ "$tty_mode" == "force" ]]; then
    out_ref+=("-tt")
  fi
  if [[ "$(wtmux_detect_platform)" == "termux" ]] || [[ "$(wtmux_transport_for_machine "$machine_id")" != "ssh" ]]; then
    out_ref+=("-o" "StrictHostKeyChecking=accept-new")
  fi
  if [[ -n "$identity_file" ]]; then
    out_ref+=("-i" "$identity_file")
  fi
  out_ref+=("$remote_target" "$remote_command")
}

wtmux_build_ssh_command() {
  local target_var="$1"
  local machine_id="$2"
  shift 2
  wtmux_build_ssh_command_internal "$target_var" "$machine_id" "none" "$@"
}

wtmux_build_ssh_tty_command() {
  local target_var="$1"
  local machine_id="$2"
  shift 2
  wtmux_build_ssh_command_internal "$target_var" "$machine_id" "force" "$@"
}

wtmux_use_ssh_client_for_tailscale_transport() {
  [[ "$(wtmux_detect_platform)" == "termux" ]]
}

wtmux_build_machine_command() {
  local target_var="$1"
  local -n out_ref="$target_var"
  local machine_id="$2"
  shift 2
  local transport
  local remote_target

  transport="$(wtmux_transport_for_machine "$machine_id")"
  case "$transport" in
    local)
      out_ref=("$@")
      ;;
    ssh)
      wtmux_build_ssh_command "$target_var" "$machine_id" "$@"
      ;;
    ""|tailscale)
      if wtmux_use_ssh_client_for_tailscale_transport; then
        wtmux_build_ssh_command "$target_var" "$machine_id" "$@"
      else
        remote_target="$(wtmux_machine_remote_target "$machine_id")"
        wtmux_build_tailscale_ssh_command "$target_var" "$remote_target" "$@"
      fi
      ;;
    *)
      wtmux_die "unsupported transport '${transport}' for ${machine_id}"
      ;;
  esac
}

wtmux_build_interactive_machine_command() {
  local target_var="$1"
  local -n out_ref="$target_var"
  local machine_id="$2"
  shift 2
  local transport
  local remote_target

  transport="$(wtmux_transport_for_machine "$machine_id")"
  case "$transport" in
    local)
      out_ref=("$@")
      ;;
    ssh)
      wtmux_build_ssh_tty_command "$target_var" "$machine_id" "$@"
      ;;
    ""|tailscale)
      # `tailscale ssh` does not expose ssh's `-t`/`-tt` flags, so interactive
      # tmux attach needs the regular ssh client even on Linux/WSL.
      wtmux_build_ssh_tty_command "$target_var" "$machine_id" "$@"
      ;;
    *)
      wtmux_die "unsupported transport '${transport}' for ${machine_id}"
      ;;
  esac
}

wtmux_exec_machine_command() {
  local machine_id="$1"
  shift
  local command=()
  local stdout_file
  local stderr_file
  local status=0

  wtmux_build_machine_command command "$machine_id" "$@"
  stdout_file="$(mktemp)"
  stderr_file="$(mktemp)"

  set +e
  "${command[@]}" >"$stdout_file" 2>"$stderr_file"
  status=$?
  set -e

  if (( status != 0 )); then
    wtmux_handle_tailscale_auth_requirement "$machine_id" "$(cat "$stderr_file")" || true
    # Structured helpers, including conversation actions, return bounded JSON
    # error frames on stdout even when their process status is non-zero. Keep
    # that frame so native clients can show the precise retryable failure.
    cat "$stdout_file"
    cat "$stderr_file" >&2
    rm -f "$stdout_file" "$stderr_file"
    return "$status"
  fi

  cat "$stdout_file"
  cat "$stderr_file" >&2
  rm -f "$stdout_file" "$stderr_file"
}

# Execute a long-lived command without buffering stdout in temporary files.
# Conversation frames are already bounded and sanitized by the host helper.
wtmux_stream_machine_command() {
  local machine_id="$1"
  shift
  local command=()

  wtmux_build_machine_command command "$machine_id" "$@"
  exec "${command[@]}"
}

wtmux_exec_machine_command_with_stdin_file() {
  local machine_id="$1"
  local stdin_path="$2"
  shift 2
  local command=()
  local stdout_file
  local stderr_file
  local status=0

  [[ -r "$stdin_path" ]] || wtmux_die "stdin file not readable: ${stdin_path}"
  wtmux_build_machine_command command "$machine_id" "$@"
  stdout_file="$(mktemp)"
  stderr_file="$(mktemp)"

  set +e
  "${command[@]}" <"$stdin_path" >"$stdout_file" 2>"$stderr_file"
  status=$?
  set -e

  if (( status != 0 )); then
    wtmux_handle_tailscale_auth_requirement "$machine_id" "$(cat "$stderr_file")" || true
    cat "$stdout_file"
    cat "$stderr_file" >&2
    rm -f "$stdout_file" "$stderr_file"
    return "$status"
  fi

  cat "$stdout_file"
  cat "$stderr_file" >&2
  rm -f "$stdout_file" "$stderr_file"
}

wtmux_default_host_command_for_machine() {
  local machine_id="$1"
  local projects_root=""
  local linux_username=""
  local home_dir=""

  projects_root="$(wtmux_machine_field "$machine_id" "projects_root")"
  linux_username="$(wtmux_machine_field "$machine_id" "linux_username")"

  if [[ -n "$projects_root" && "$projects_root" == */projects ]]; then
    home_dir="${projects_root%/projects}"
  elif [[ -n "$linux_username" ]]; then
    home_dir="/home/${linux_username}"
  fi

  if [[ -n "$home_dir" ]]; then
    printf '%s/.local/bin/wtmux-host\n' "$home_dir"
    return 0
  fi

  printf '%s\n' "wtmux-host"
}

wtmux_machine_host_command() {
  local machine_id="$1"
  local command_name
  command_name="$(wtmux_machine_field "$machine_id" "host_command")"
  if [[ -z "$command_name" || "$command_name" == "wtmux-host" ]]; then
    wtmux_default_host_command_for_machine "$machine_id"
    return 0
  fi
  printf '%s\n' "$command_name"
}

wtmux_exec_host_command() {
  local machine_id="$1"
  shift
  local transport
  local command=()
  local host_command

  transport="$(wtmux_transport_for_machine "$machine_id")"
  host_command="$(wtmux_machine_host_command "$machine_id")"

  if [[ "$transport" == "local" ]]; then
    command=("${WTMUX_REPO_ROOT}/scripts/wtmux-host" "--machine" "$machine_id" "$@")
  else
    command=("$host_command" "--machine" "$machine_id" "$@")
  fi

  wtmux_exec_machine_command "$machine_id" "${command[@]}"
}

wtmux_stream_host_command() {
  local machine_id="$1"
  shift
  local transport
  local command=()
  local host_command

  transport="$(wtmux_transport_for_machine "$machine_id")"
  host_command="$(wtmux_machine_host_command "$machine_id")"

  if [[ "$transport" == "local" ]]; then
    command=("${WTMUX_REPO_ROOT}/scripts/wtmux-host" "--machine" "$machine_id" "$@")
  else
    command=("$host_command" "--machine" "$machine_id" "$@")
  fi

  wtmux_stream_machine_command "$machine_id" "${command[@]}"
}

wtmux_exec_host_command_with_stdin_file() {
  local machine_id="$1"
  local stdin_path="$2"
  shift 2
  local transport
  local command=()
  local host_command

  transport="$(wtmux_transport_for_machine "$machine_id")"
  host_command="$(wtmux_machine_host_command "$machine_id")"

  if [[ "$transport" == "local" ]]; then
    command=("${WTMUX_REPO_ROOT}/scripts/wtmux-host" "--machine" "$machine_id" "$@")
  else
    command=("$host_command" "--machine" "$machine_id" "$@")
  fi

  wtmux_exec_machine_command_with_stdin_file "$machine_id" "$stdin_path" "${command[@]}"
}

wtmux_probe_machine() {
  local machine_id="$1"
  local host_command
  local probe_command=()
  local output=""
  local status=0
  local transport

  transport="$(wtmux_transport_for_machine "$machine_id")"
  host_command="$(wtmux_machine_host_command "$machine_id")"

  if [[ "$transport" == "local" ]]; then
    if [[ -x "${WTMUX_REPO_ROOT}/scripts/wtmux-host" ]]; then
      WTMUX_LAST_PROBE_COMMAND="${WTMUX_REPO_ROOT}/scripts/wtmux-host --help"
      WTMUX_LAST_PROBE_OUTPUT=""
      WTMUX_LAST_PROBE_STATUS="ok"
      return 0
    fi
    WTMUX_LAST_PROBE_COMMAND="${WTMUX_REPO_ROOT}/scripts/wtmux-host --help"
    WTMUX_LAST_PROBE_OUTPUT="local host runtime is missing or not executable"
    WTMUX_LAST_PROBE_STATUS="missing_local_setup"
    return 1
  fi

  wtmux_build_machine_command probe_command "$machine_id" "$host_command" "--help"
  WTMUX_LAST_PROBE_COMMAND="$(wtmux_shell_quote_join "${probe_command[@]}")"

  set +e
  output="$("${probe_command[@]}" 2>&1)"
  status=$?
  set -e

  WTMUX_LAST_PROBE_OUTPUT="$output"
  if wtmux_handle_tailscale_auth_requirement "$machine_id" "$output"; then
    WTMUX_LAST_PROBE_STATUS="auth_failure"
    return 1
  fi
  case "$status" in
    0)
      WTMUX_LAST_PROBE_STATUS="ok"
      return 0
      ;;
    126|127)
      WTMUX_LAST_PROBE_STATUS="missing_host_runtime"
      ;;
    *)
      if [[ "$output" == *"Permission denied"* ]] || [[ "$output" == *"failed to authenticate"* ]]; then
        WTMUX_LAST_PROBE_STATUS="auth_failure"
      elif [[ "$output" == *"Connection refused"* ]] || [[ "$output" == *"Connection timed out"* ]] || [[ "$output" == *"No route to host"* ]] || [[ "$output" == *"Could not resolve hostname"* ]] || [[ "$output" == *"network is unreachable"* ]] || [[ "$output" == *"context deadline exceeded"* ]] || [[ "$output" == *"failed to connect"* ]]; then
        WTMUX_LAST_PROBE_STATUS="unreachable"
      else
        WTMUX_LAST_PROBE_STATUS="probe_failed"
      fi
      ;;
  esac
  return 1
}
