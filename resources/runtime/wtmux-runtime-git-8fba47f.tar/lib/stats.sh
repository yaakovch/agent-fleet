#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_STATS_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_STATS_SH=1

wtmux_stats_is_wsl() {
  if [[ -n "${WTMUX_STATS_WINDOWS:-}" ]]; then
    case "${WTMUX_STATS_WINDOWS,,}" in
      1|true|yes|windows|wsl)
        return 0
        ;;
      0|false|no|linux)
        return 1
        ;;
    esac
  fi

  [[ -n "${WSL_INTEROP:-}" ]] || grep -qiE '(microsoft|wsl)' /proc/version 2>/dev/null
}

wtmux_stats_powershell_path() {
  local candidate
  local candidates=(
    "powershell.exe"
    "pwsh.exe"
    "/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe"
    "/mnt/c/Program Files/PowerShell/7/pwsh.exe"
  )

  if [[ -n "${WTMUX_POWERSHELL:-}" ]]; then
    printf '%s\n' "$WTMUX_POWERSHELL"
    return 0
  fi

  for candidate in "${candidates[@]}"; do
    if [[ "$candidate" == */* ]]; then
      if [[ -f "$candidate" ]]; then
        printf '%s\n' "$candidate"
        return 0
      fi
    else
      if command -v "$candidate" >/dev/null 2>&1; then
        command -v "$candidate"
        return 0
      fi
    fi
  done

  return 1
}

wtmux_stats_windows_status_line() {
  local powershell
  local output

  powershell="$(wtmux_stats_powershell_path)" || return 1
  output="$(
    "$powershell" -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command - 2>/dev/null <<'POWERSHELL' | tr -d '\r' | sed '/^[[:space:]]*$/d' | tail -n 1
$ErrorActionPreference = 'SilentlyContinue'

$cpu = $null
try {
  $cpuMeasure = Get-CimInstance -ClassName Win32_Processor | Measure-Object -Property LoadPercentage -Average
  if ($null -ne $cpuMeasure -and $null -ne $cpuMeasure.Average) {
    $cpu = [int][Math]::Round([double]$cpuMeasure.Average)
  }
} catch {}

$memory = $null
try {
  $os = Get-CimInstance -ClassName Win32_OperatingSystem
  if ($null -ne $os -and [double]$os.TotalVisibleMemorySize -gt 0) {
    $used = [double]$os.TotalVisibleMemorySize - [double]$os.FreePhysicalMemory
    if ($used -lt 0) {
      $used = 0
    }
    $memory = [int][Math]::Round(($used * 100.0) / [double]$os.TotalVisibleMemorySize)
  }
} catch {}

$gpuText = 'GPU n/a'
try {
  $nvidiaPath = $null
  $nvidiaCommand = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
  if ($null -ne $nvidiaCommand) {
    $nvidiaPath = $nvidiaCommand.Source
  }
  if (-not $nvidiaPath -and $env:WINDIR) {
    $candidate = Join-Path $env:WINDIR 'System32\nvidia-smi.exe'
    if (Test-Path $candidate) {
      $nvidiaPath = $candidate
    }
  }

  if ($nvidiaPath) {
    $rows = & $nvidiaPath --query-gpu=index,utilization.gpu,memory.used,memory.total --format=csv,noheader,nounits 2>$null
    $segments = @()
    foreach ($row in @($rows)) {
      $parts = $row -split ','
      if ($parts.Count -lt 4) {
        continue
      }
      $gpuIndex = $parts[0].Trim()
      $util = $parts[1].Trim()
      $used = $parts[2].Trim()
      $total = $parts[3].Trim()
      if ($gpuIndex -match '^\d+$' -and $util -match '^\d+$' -and $used -match '^\d+$' -and $total -match '^\d+$') {
        $segments += "G$gpuIndex $util% $used/$($total)MiB"
      }
    }
    if ($segments.Count -gt 0) {
      $gpuText = $segments -join ' '
    }
  }
} catch {}

if ($null -ne $cpu) {
  $cpuText = "CPU $cpu%"
} else {
  $cpuText = 'CPU n/a'
}
if ($null -ne $memory) {
  $memoryText = "MEM $memory%"
} else {
  $memoryText = 'MEM n/a'
}

Write-Output "$cpuText $memoryText $gpuText"
POWERSHELL
  )" || return 1

  [[ -n "$output" ]] || return 1
  [[ "$output" == CPU\ *\ MEM\ * ]] || return 1
  printf '%s\n' "$output"
}

wtmux_stats_read_cpu_totals() {
  local stat_path="${WTMUX_PROC_STAT_PATH:-/proc/stat}"
  local line label user nice system idle iowait irq softirq steal guest guest_nice
  local idle_all non_idle total

  [[ -r "$stat_path" ]] || return 1
  IFS= read -r line <"$stat_path" || return 1
  read -r label user nice system idle iowait irq softirq steal guest guest_nice <<<"$line"
  [[ "$label" == "cpu" ]] || return 1

  idle_all=$(( ${idle:-0} + ${iowait:-0} ))
  non_idle=$(( ${user:-0} + ${nice:-0} + ${system:-0} + ${irq:-0} + ${softirq:-0} + ${steal:-0} ))
  total=$(( idle_all + non_idle ))
  (( total > 0 )) || return 1

  printf '%s %s\n' "$total" "$idle_all"
}

wtmux_stats_cpu_percent() {
  local first second total_1 idle_1 total_2 idle_2
  local total_delta idle_delta active_delta sleep_seconds

  first="$(wtmux_stats_read_cpu_totals)" || return 1
  sleep_seconds="${WTMUX_STATS_CPU_SAMPLE_SECONDS:-0.1}"
  if ! sleep "$sleep_seconds" 2>/dev/null; then
    sleep 1 || return 1
  fi
  second="$(wtmux_stats_read_cpu_totals)" || return 1

  read -r total_1 idle_1 <<<"$first"
  read -r total_2 idle_2 <<<"$second"
  total_delta=$(( total_2 - total_1 ))
  idle_delta=$(( idle_2 - idle_1 ))
  (( total_delta > 0 )) || return 1

  active_delta=$(( total_delta - idle_delta ))
  (( active_delta < 0 )) && active_delta=0
  (( active_delta > total_delta )) && active_delta="$total_delta"

  printf '%d\n' $(( active_delta * 100 / total_delta ))
}

wtmux_stats_memory_percent() {
  command -v free >/dev/null 2>&1 || return 1

  free -m 2>/dev/null | awk '
    NR == 1 {
      for (i = 1; i <= NF; i++) {
        header[$i] = i + 1
      }
      next
    }
    $1 == "Mem:" {
      total = $2 + 0
      if (total <= 0) {
        exit 1
      }
      if (("available" in header) && NF >= header["available"]) {
        used = total - $(header["available"])
      } else {
        used = $3 + 0
      }
      if (used < 0) {
        used = 0
      }
      if (used > total) {
        used = total
      }
      printf "%d\n", (used * 100) / total
      found = 1
      exit
    }
    END {
      if (!found) {
        exit 1
      }
    }
  '
}

wtmux_stats_gpu_status() {
  local output

  command -v nvidia-smi >/dev/null 2>&1 || return 1
  output="$(nvidia-smi --query-gpu=index,utilization.gpu,memory.used,memory.total --format=csv,noheader,nounits 2>/dev/null)" || return 1
  [[ -n "$output" ]] || return 1

  awk -F',' '
    function trim(value) {
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
      return value
    }
    NF >= 4 {
      gpu_index = trim($1)
      util = trim($2)
      used = trim($3)
      total = trim($4)
      if (gpu_index !~ /^[0-9]+$/ || util !~ /^[0-9]+$/ || used !~ /^[0-9]+$/ || total !~ /^[0-9]+$/) {
        exit 1
      }
      segment = sprintf("G%s %s%% %s/%sMiB", gpu_index, util, used, total)
      if (found) {
        output = output " " segment
      } else {
        output = segment
      }
      found = 1
    }
    END {
      if (!found) {
        exit 1
      }
      print output
    }
  ' <<<"$output"
}

wtmux_stats_status_line() {
  local cpu_text="CPU n/a"
  local memory_text="MEM n/a"
  local gpu_text="GPU n/a"
  local value

  if wtmux_stats_is_wsl && value="$(wtmux_stats_windows_status_line 2>/dev/null)"; then
    printf '%s\n' "$value"
    return 0
  fi

  if value="$(wtmux_stats_cpu_percent 2>/dev/null)" && [[ "$value" =~ ^[0-9]+$ ]]; then
    cpu_text="CPU ${value}%"
  fi
  if value="$(wtmux_stats_memory_percent 2>/dev/null)" && [[ "$value" =~ ^[0-9]+$ ]]; then
    memory_text="MEM ${value}%"
  fi
  if value="$(wtmux_stats_gpu_status 2>/dev/null)" && [[ -n "$value" ]]; then
    gpu_text="$value"
  fi

  printf '%s %s %s\n' "$cpu_text" "$memory_text" "$gpu_text"
}
