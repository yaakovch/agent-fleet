#!/usr/bin/env bash
set -euo pipefail

SELF="${BASH_SOURCE[0]}"
while [[ -L "$SELF" ]]; do
  DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
  TARGET="$(readlink "$SELF")"
  if [[ "$TARGET" != /* ]]; then
    SELF="${DIR}/${TARGET}"
  else
    SELF="$TARGET"
  fi
done
SCRIPT_DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
WTMUX_REPO_ROOT="$(cd -P "${SCRIPT_DIR}/.." >/dev/null 2>&1 && pwd)"

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/platform.sh"

WINDOWS_REPO_PATH="$(wslpath -w "$WTMUX_REPO_ROOT" 2>/dev/null || printf '%s\n' "$WTMUX_REPO_ROOT")"
WSL_DISTRO="$(wtmux_get_wsl_distro 2>/dev/null || printf '%s\n' "Ubuntu")"

cat <<EOF
PowerShell commands for this checkout:

Set-Location "$WINDOWS_REPO_PATH"
powershell -ExecutionPolicy Bypass -File ".\\windows-install-shim.ps1" -Distro "$WSL_DISTRO"
wsl.exe -d "$WSL_DISTRO" -- bash -lc "cd $(printf '%q' "$WTMUX_REPO_ROOT") && ./setup.sh --repair"
EOF
