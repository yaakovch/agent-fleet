#!/usr/bin/env bash
set -euo pipefail

SELF="${BASH_SOURCE[0]}"
while [[ -L "$SELF" ]]; do
  DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
  TARGET="$(readlink "$SELF")"
  if [[ "$TARGET" != /* ]]; then
    SELF="${DIR}/${TARGET}"
  else
    SELF="$TARGET"
  fi
done
SCRIPT_DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
WTMUX_REPO_ROOT="$(cd -P "${SCRIPT_DIR}/.." >/dev/null 2>&1 && pwd)"

exec "${WTMUX_REPO_ROOT}/setup.sh" --refresh-only
