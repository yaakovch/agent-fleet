"""Protect managed tmux panes from fragmented terminal capability replies."""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
from typing import Sequence


COMMAND_TIMEOUT_SECONDS = 5
MAX_COMMAND_OUTPUT_BYTES = 64 * 1024
ROW_SEPARATOR = "\x1f"
GUARD_MARKER = "@wtmux_terminal_reply_guard"
HOOK_MARKER = "@wtmux_terminal_reply_hooks"
GUARD_VERSION = "v1"
HOOKS = (("after-split-window", 90821), ("after-new-window", 90822))
PALETTE = (
    "#000000",
    "#cd0000",
    "#00cd00",
    "#cdcd00",
    "#0000ee",
    "#cd00cd",
    "#00cdcd",
    "#e5e5e5",
    "#7f7f7f",
    "#ff0000",
    "#00ff00",
    "#ffff00",
    "#5c5cff",
    "#ff00ff",
    "#00ffff",
    "#ffffff",
)
SESSION_RE = re.compile(r"^[A-Za-z0-9._:+-]{1,320}$")
VERSION_RE = re.compile(r"^(?:tmux\s+)?(\d+)\.(\d+)([^\s]*)$")
PALETTE_ROW_RE = re.compile(r"^pane-colours\[(\d+)]\s+(.+)$")


class TmuxSafetyError(RuntimeError):
    """Raised when the active tmux server cannot be inspected or protected."""


@dataclass(frozen=True)
class TmuxSafetyStatus:
    clientVersion: str
    serverVersion: str
    terminalReplySafety: str
    managedPanes: int
    guardedPanes: int


def normalized_version(value: str) -> str:
    match = VERSION_RE.fullmatch(value.strip())
    return f"{match.group(1)}.{match.group(2)}{match.group(3)}" if match else ""


def version_safety(value: str) -> str:
    """Classify the tmux OSC-4 forwarding/parser behavior by server version."""
    normalized = normalized_version(value)
    match = VERSION_RE.fullmatch(normalized)
    if not match:
        return "unknown"
    major, minor = int(match.group(1)), int(match.group(2))
    if (major, minor) == (3, 6):
        return "vulnerable"
    return "safe"


class Tmux:
    def __init__(self, command: Sequence[str] = ("tmux",)) -> None:
        if not command or any(not part or "\x00" in part for part in command):
            raise ValueError("tmux command is invalid")
        self.command = tuple(command)

    def run(self, *arguments: str, check: bool = True) -> subprocess.CompletedProcess[bytes]:
        try:
            result = subprocess.run(
                [*self.command, *arguments],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=COMMAND_TIMEOUT_SECONDS,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise TmuxSafetyError("tmux command could not be completed") from error
        if len(result.stdout) > MAX_COMMAND_OUTPUT_BYTES or len(result.stderr) > MAX_COMMAND_OUTPUT_BYTES:
            raise TmuxSafetyError("tmux command output exceeded its safety limit")
        if check and result.returncode != 0:
            raise TmuxSafetyError("tmux command failed")
        return result

    def text(self, *arguments: str, check: bool = True) -> str:
        return self.run(*arguments, check=check).stdout.decode("utf-8", "replace").strip()


def command_from_environment() -> tuple[str, ...]:
    command: tuple[str, ...] = (os.environ.get("WTMUX_TMUX_BIN") or "tmux",)
    socket_name = os.environ.get("WTMUX_SCHEDULER_TMUX_SOCKET")
    if socket_name:
        command += ("-L", socket_name)
    return command


def client_version(tmux: Tmux) -> str:
    try:
        return tmux.text("-V")
    except TmuxSafetyError:
        return "missing"


def server_version(tmux: Tmux) -> str:
    try:
        return normalized_version(tmux.text("display-message", "-p", "#{version}")) or "unknown"
    except TmuxSafetyError:
        return "not-running"


def managed_sessions(tmux: Tmux, requested: str | None = None) -> list[str]:
    if requested is not None:
        if not SESSION_RE.fullmatch(requested):
            raise TmuxSafetyError("tmux session name is invalid")
        managed = tmux.text("show-options", "-t", requested, "-q", "-v", "@wtmux_managed")
        if managed != "1":
            raise TmuxSafetyError("tmux session is not managed by wtmux")
        return [requested]

    rows = tmux.text(
        "list-sessions",
        "-F",
        f"#{{session_name}}{ROW_SEPARATOR}#{{@wtmux_managed}}",
    )
    sessions: list[str] = []
    for row in rows.splitlines():
        parts = row.split(ROW_SEPARATOR)
        if len(parts) != 2 or parts[1] != "1" or not SESSION_RE.fullmatch(parts[0]):
            continue
        sessions.append(parts[0])
    return sessions


def managed_panes(tmux: Tmux, requested: str | None = None) -> list[str]:
    panes: list[str] = []
    for session in managed_sessions(tmux, requested):
        output = tmux.text("list-panes", "-s", "-t", session, "-F", "#{pane_id}")
        for pane in output.splitlines():
            if re.fullmatch(r"%\d+", pane):
                panes.append(pane)
    return list(dict.fromkeys(panes))


def pane_palette(tmux: Tmux, pane: str) -> dict[int, str]:
    output = tmux.text("show-options", "-p", "-t", pane, "pane-colours", check=False)
    result: dict[int, str] = {}
    for row in output.splitlines():
        match = PALETTE_ROW_RE.fullmatch(row)
        if not match:
            continue
        index = int(match.group(1))
        if 0 <= index <= 255:
            result[index] = match.group(2)
    return result


def pane_is_guarded(tmux: Tmux, pane: str) -> bool:
    palette = pane_palette(tmux, pane)
    return all(index in palette for index in range(len(PALETTE)))


def marker_indexes(value: str) -> set[int]:
    prefix = f"{GUARD_VERSION}:"
    if not value.startswith(prefix):
        return set()
    raw_indexes = value.removeprefix(prefix)
    if not raw_indexes:
        return set()
    indexes: set[int] = set()
    for raw in raw_indexes.split(","):
        if not raw.isdigit():
            return set()
        index = int(raw)
        if not 0 <= index < len(PALETTE):
            return set()
        indexes.add(index)
    return indexes


def install_guard(tmux: Tmux, pane: str) -> None:
    current = pane_palette(tmux, pane)
    existing_marker = tmux.text(
        "show-options", "-p", "-t", pane, "-q", "-v", GUARD_MARKER, check=False,
    )
    owned = marker_indexes(existing_marker)
    for index, colour in enumerate(PALETTE):
        if index in current:
            continue
        tmux.run("set-option", "-p", "-t", pane, "-q", f"pane-colours[{index}]", colour)
        owned.add(index)
    marker = f"{GUARD_VERSION}:{','.join(str(index) for index in sorted(owned))}"
    tmux.run("set-option", "-p", "-t", pane, "-q", GUARD_MARKER, marker)
    if not pane_is_guarded(tmux, pane):
        raise TmuxSafetyError("tmux pane palette guard could not be verified")


def remove_owned_guard(tmux: Tmux, pane: str) -> None:
    marker = tmux.text(
        "show-options", "-p", "-t", pane, "-q", "-v", GUARD_MARKER, check=False,
    )
    owned = marker_indexes(marker)
    if not owned and not marker.startswith(f"{GUARD_VERSION}:"):
        return
    current = pane_palette(tmux, pane)
    for index in sorted(owned):
        if current.get(index, "").lower() == PALETTE[index]:
            tmux.run("set-option", "-p", "-t", pane, "-q", "-u", f"pane-colours[{index}]")
    tmux.run("set-option", "-p", "-t", pane, "-q", "-u", GUARD_MARKER)


def hook_command() -> str:
    launcher = shutil.which("wtmux-tmux-safety")
    arguments = (
        *((launcher,) if launcher else (sys.executable, str(Path(__file__).resolve().parents[1] / "scripts" / "wtmux-tmux-safety"))),
        "apply",
        "--session",
        "#{session_name}",
    )
    command = shlex.join(arguments)
    return f"run-shell -b {shlex.quote(f'{command} >/dev/null 2>&1')}"


def hook_matches(existing: str, target: str, expected: str) -> bool:
    """Compare a rendered hook by argv because tmux normalizes shell quoting."""
    rows = existing.splitlines()
    if len(rows) != 1:
        return False
    try:
        return shlex.split(rows[0]) == [target, *shlex.split(expected)]
    except ValueError:
        return False


def install_session_hooks(tmux: Tmux, session: str) -> None:
    expected = hook_command()
    for hook_name, index in HOOKS:
        target = f"{hook_name}[{index}]"
        existing = tmux.text("show-hooks", "-t", session, target, check=False)
        if existing and not hook_matches(existing, target, expected):
            raise TmuxSafetyError(f"managed tmux hook slot is already occupied: {target}")
    for hook_name, index in HOOKS:
        tmux.run("set-hook", "-t", session, f"{hook_name}[{index}]", expected)
    tmux.run("set-option", "-t", session, "-q", HOOK_MARKER, GUARD_VERSION)


def remove_session_hooks(tmux: Tmux, session: str) -> None:
    marker = tmux.text("show-options", "-t", session, "-q", "-v", HOOK_MARKER, check=False)
    if marker != GUARD_VERSION:
        return
    expected = hook_command()
    for hook_name, index in HOOKS:
        target = f"{hook_name}[{index}]"
        existing = tmux.text("show-hooks", "-t", session, target, check=False)
        if hook_matches(existing, target, expected):
            tmux.run("set-hook", "-t", session, "-u", target)
    tmux.run("set-option", "-t", session, "-q", "-u", HOOK_MARKER)


def inspect(tmux: Tmux, requested: str | None = None) -> TmuxSafetyStatus:
    installed = client_version(tmux)
    active = server_version(tmux)
    if installed == "missing":
        return TmuxSafetyStatus(installed, active, "missing", 0, 0)
    if active == "not-running":
        return TmuxSafetyStatus(installed, active, "inactive", 0, 0)
    classification = version_safety(active)
    if classification == "safe":
        return TmuxSafetyStatus(installed, active, "safe", 0, 0)
    if classification != "vulnerable":
        return TmuxSafetyStatus(installed, active, "unknown", 0, 0)
    try:
        panes = managed_panes(tmux, requested)
    except TmuxSafetyError:
        return TmuxSafetyStatus(installed, active, "unknown", 0, 0)
    guarded = sum(pane_is_guarded(tmux, pane) for pane in panes)
    state = "mitigated" if guarded == len(panes) else "vulnerable"
    return TmuxSafetyStatus(installed, active, state, len(panes), guarded)


def apply(tmux: Tmux, requested: str | None = None) -> TmuxSafetyStatus:
    active = server_version(tmux)
    if active == "not-running":
        return inspect(tmux, requested)
    classification = version_safety(active)
    if classification == "unknown":
        raise TmuxSafetyError("active tmux server version is unsupported")
    sessions = managed_sessions(tmux, requested)
    panes: list[str] = []
    for session in sessions:
        panes.extend(managed_panes(tmux, session))
    panes = list(dict.fromkeys(panes))
    if classification == "vulnerable":
        for pane in panes:
            install_guard(tmux, pane)
        for session in sessions:
            install_session_hooks(tmux, session)
    else:
        for pane in panes:
            remove_owned_guard(tmux, pane)
        for session in sessions:
            remove_session_hooks(tmux, session)
    status = inspect(tmux, requested)
    if status.terminalReplySafety not in {"safe", "mitigated", "inactive"}:
        raise TmuxSafetyError("active tmux server remains vulnerable to terminal reply injection")
    return status


def kv_status(status: TmuxSafetyStatus) -> str:
    return (
        f"tmux_client_version={status.clientVersion}\t"
        f"tmux_server_version={status.serverVersion}\t"
        f"terminal_reply_safety={status.terminalReplySafety}\t"
        f"managed_panes={status.managedPanes}\tguarded_panes={status.guardedPanes}"
    )


def main(arguments: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("status", "apply"))
    parser.add_argument("--session")
    parser.add_argument("--kv", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(arguments)
    if args.kv and args.json:
        parser.error("--kv and --json are mutually exclusive")
    tmux = Tmux(command_from_environment())
    try:
        status = apply(tmux, args.session) if args.command == "apply" else inspect(tmux, args.session)
    except TmuxSafetyError as error:
        print(f"wtmux tmux safety: {error}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(asdict(status), sort_keys=True, separators=(",", ":")))
    elif args.kv:
        print(kv_status(status))
    else:
        print(
            f"terminal reply safety: {status.terminalReplySafety}; "
            f"tmux client={status.clientVersion}; server={status.serverVersion}; "
            f"guarded panes={status.guardedPanes}/{status.managedPanes}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
