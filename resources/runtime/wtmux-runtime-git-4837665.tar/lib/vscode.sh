#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_VSCODE_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_VSCODE_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/platform.sh"

WTMUX_VSCODE_SETTINGS_STATUS=""
WTMUX_VSCODE_SETTINGS_RESOLVED_PATH=""
WTMUX_VSCODE_PROFILE_STATUS=""
WTMUX_VSCODE_COMPANION_STATUS=""
WTMUX_VSCODE_PERSISTENCE_STATUS=""
WTMUX_VSCODE_CLI_RESOLVED_PATH=""

wtmux_vscode_windows_appdata_path() {
  local windows_appdata=""
  local windows_appdata_unix=""
  local cmd_path=""

  if [[ -n "${WTMUX_WINDOWS_APPDATA:-}" ]]; then
    printf '%s\n' "$WTMUX_WINDOWS_APPDATA"
    return 0
  fi

  if command -v cmd.exe >/dev/null 2>&1; then
    cmd_path="$(command -v cmd.exe)"
  elif [[ -x /mnt/c/Windows/System32/cmd.exe ]]; then
    cmd_path="/mnt/c/Windows/System32/cmd.exe"
  fi

  if [[ -n "$cmd_path" ]] && command -v wslpath >/dev/null 2>&1; then
    windows_appdata="$($cmd_path /d /c 'echo %APPDATA%' 2>/dev/null | tr -d '\r' | tail -n 1)"
    if [[ "$windows_appdata" == *:\\* ]]; then
      windows_appdata_unix="$(wslpath -u "$windows_appdata" 2>/dev/null || true)"
    fi
  fi

  [[ -n "$windows_appdata_unix" ]] || return 1
  printf '%s\n' "$windows_appdata_unix"
}

wtmux_vscode_settings_path() {
  local platform
  local appdata=""
  local windows_user_home=""
  local candidates=()
  local candidate_dirs=()

  if [[ -n "${WTMUX_VSCODE_SETTINGS_PATH:-}" ]]; then
    printf '%s\n' "$WTMUX_VSCODE_SETTINGS_PATH"
    return 0
  fi

  platform="$(wtmux_detect_platform)"
  case "$platform" in
    wsl)
      appdata="$(wtmux_vscode_windows_appdata_path 2>/dev/null || true)"
      if [[ -n "$appdata" ]]; then
        if [[ -d "${appdata}/Code/User" || -f "${appdata}/Code/User/settings.json" ]]; then
          printf '%s\n' "${appdata}/Code/User/settings.json"
          return 0
        fi
        if [[ -d "${appdata}/Code - Insiders/User" || -f "${appdata}/Code - Insiders/User/settings.json" ]]; then
          printf '%s\n' "${appdata}/Code - Insiders/User/settings.json"
          return 0
        fi
      fi

      if [[ "${VSCODE_WSL_EXT_LOCATION:-}" == */.vscode/extensions/* ]]; then
        windows_user_home="${VSCODE_WSL_EXT_LOCATION%%/.vscode/extensions/*}"
        if [[ -d "${windows_user_home}/AppData/Roaming/Code/User" ]]; then
          printf '%s\n' "${windows_user_home}/AppData/Roaming/Code/User/settings.json"
          return 0
        fi
      fi

      shopt -s nullglob
      candidates=(/mnt/c/Users/*/AppData/Roaming/Code/User/settings.json)
      shopt -u nullglob
      if [[ "${#candidates[@]}" -eq 1 ]]; then
        printf '%s\n' "${candidates[0]}"
        return 0
      fi
      shopt -s nullglob
      candidate_dirs=(/mnt/c/Users/*/AppData/Roaming/Code/User)
      shopt -u nullglob
      if [[ "${#candidate_dirs[@]}" -eq 1 ]]; then
        printf '%s\n' "${candidate_dirs[0]}/settings.json"
        return 0
      fi
      ;;
    linux)
      if [[ -d "${HOME}/.config/Code/User" || -f "${HOME}/.config/Code/User/settings.json" ]]; then
        printf '%s\n' "${HOME}/.config/Code/User/settings.json"
        return 0
      fi
      if [[ -d "${HOME}/.config/Code - Insiders/User" || -f "${HOME}/.config/Code - Insiders/User/settings.json" ]]; then
        printf '%s\n' "${HOME}/.config/Code - Insiders/User/settings.json"
        return 0
      fi
      ;;
  esac

  return 1
}

wtmux_vscode_setting_is_title() {
  local settings_path="$1"
  grep -Eq '^[[:space:]]*"terminal\.integrated\.tabs\.title"[[:space:]]*:[[:space:]]*"\$\{sequence\}"[[:space:]]*,?[[:space:]]*(//.*)?\r?$' "$settings_path"
}

wtmux_vscode_setting_is_description() {
  local settings_path="$1"
  grep -Eq '^[[:space:]]*"terminal\.integrated\.tabs\.description"[[:space:]]*:[[:space:]]*""[[:space:]]*,?[[:space:]]*(//.*)?\r?$' "$settings_path"
}

wtmux_vscode_write_new_settings() {
  local settings_path="$1"
  local temp_path

  wtmux_ensure_parent_dir "$settings_path" || return 1
  temp_path="$(mktemp "${settings_path}.wtmux.XXXXXX")" || return 1
  if ! {
    printf '{\n'
    printf '    "terminal.integrated.tabs.title": "${sequence}",\n'
    printf '    "terminal.integrated.tabs.description": ""\n'
    printf '}\n'
  } >"$temp_path"; then
    rm -f "$temp_path"
    return 1
  fi
  if ! mv "$temp_path" "$settings_path"; then
    rm -f "$temp_path"
    return 1
  fi
}

wtmux_vscode_rewrite_settings() {
  local settings_path="$1"
  local temp_path
  local add_title=1
  local add_description=1
  local crlf=0

  if grep -Eq '"terminal\.integrated\.tabs\.title"[[:space:]]*:' "$settings_path"; then
    add_title=0
  fi
  if grep -Eq '"terminal\.integrated\.tabs\.description"[[:space:]]*:' "$settings_path"; then
    add_description=0
  fi
  if [[ "$(grep -Ec '"terminal\.integrated\.tabs\.title"[[:space:]]*:' "$settings_path")" -gt 1 ]] || \
    [[ "$(grep -Ec '"terminal\.integrated\.tabs\.description"[[:space:]]*:' "$settings_path")" -gt 1 ]]; then
    return 1
  fi
  if LC_ALL=C head -n 1 "$settings_path" | grep -q $'\r$'; then
    crlf=1
  fi

  temp_path="$(mktemp "${settings_path}.wtmux.XXXXXX")" || return 1
  if ! awk \
    -v add_title="$add_title" \
    -v add_description="$add_description" \
    -v crlf="$crlf" '
      BEGIN {
        inserted = 0
        ORS = crlf == 1 ? "\r\n" : "\n"
      }

      function indentation(value, first_nonspace) {
        first_nonspace = match(value, /[^ \t]/)
        return first_nonspace > 1 ? substr(value, 1, first_nonspace - 1) : ""
      }

      {
        sub(/\r$/, "", $0)
        line = $0

        if (line ~ /"terminal\.integrated\.tabs\.title"[ \t]*:/) {
          if (line !~ /^[ \t]*"terminal\.integrated\.tabs\.title"[ \t]*:[ \t]*"([^"\\]|\\.)*"[ \t]*,?[ \t]*(\/\/.*)?$/) {
            exit 20
          }
          comma = line ~ /,[ \t]*(\/\/.*)?$/ ? "," : ""
          print indentation(line) "\"terminal.integrated.tabs.title\": \"${sequence}\"" comma
          next
        }

        if (line ~ /"terminal\.integrated\.tabs\.description"[ \t]*:/) {
          if (line !~ /^[ \t]*"terminal\.integrated\.tabs\.description"[ \t]*:[ \t]*"([^"\\]|\\.)*"[ \t]*,?[ \t]*(\/\/.*)?$/) {
            exit 21
          }
          comma = line ~ /,[ \t]*(\/\/.*)?$/ ? "," : ""
          print indentation(line) "\"terminal.integrated.tabs.description\": \"\"" comma
          next
        }

        if (!inserted && (add_title == 1 || add_description == 1)) {
          opening = index(line, "{")
          if (opening > 0) {
            print substr(line, 1, opening)
            if (add_title == 1) {
              print "    \"terminal.integrated.tabs.title\": \"${sequence}\","
            }
            if (add_description == 1) {
              print "    \"terminal.integrated.tabs.description\": \"\","
            }
            remainder = substr(line, opening + 1)
            if (remainder ~ /[^ \t]/) {
              print remainder
            }
            inserted = 1
            next
          }
        }

        print line
      }

      END {
        if ((add_title == 1 || add_description == 1) && !inserted) {
          exit 22
        }
      }
    ' "$settings_path" >"$temp_path"; then
    rm -f "$temp_path"
    return 1
  fi

  if ! wtmux_vscode_setting_is_title "$temp_path" || ! wtmux_vscode_setting_is_description "$temp_path"; then
    rm -f "$temp_path"
    return 1
  fi

  chmod --reference="$settings_path" "$temp_path" 2>/dev/null || true
  if ! mv "$temp_path" "$settings_path"; then
    rm -f "$temp_path"
    return 1
  fi
}

wtmux_vscode_configure_terminal_tabs() {
  local settings_path=""

  WTMUX_VSCODE_SETTINGS_STATUS=""
  WTMUX_VSCODE_SETTINGS_RESOLVED_PATH=""

  settings_path="$(wtmux_vscode_settings_path 2>/dev/null || true)"
  if [[ -z "$settings_path" ]]; then
    WTMUX_VSCODE_SETTINGS_STATUS="not-detected"
    return 2
  fi
  WTMUX_VSCODE_SETTINGS_RESOLVED_PATH="$settings_path"

  if [[ -f "$settings_path" ]] && wtmux_vscode_setting_is_title "$settings_path" && wtmux_vscode_setting_is_description "$settings_path"; then
    WTMUX_VSCODE_SETTINGS_STATUS="configured"
    return 0
  fi

  if [[ ! -e "$settings_path" || ! -s "$settings_path" ]]; then
    if ! wtmux_vscode_write_new_settings "$settings_path"; then
      WTMUX_VSCODE_SETTINGS_STATUS="error"
      return 1
    fi
  elif ! wtmux_vscode_rewrite_settings "$settings_path"; then
    WTMUX_VSCODE_SETTINGS_STATUS="error"
    return 1
  fi

  WTMUX_VSCODE_SETTINGS_STATUS="updated"
  return 0
}

wtmux_vscode_profile_tool() {
  printf '%s/scripts/wtmux-vscode-settings\n' "$WTMUX_REPO_ROOT"
}

wtmux_vscode_configure_managed_profile() {
  local settings_path=""
  local distro="${1:-Ubuntu}"
  local output=""
  local status=0

  WTMUX_VSCODE_PROFILE_STATUS=""
  settings_path="$(wtmux_vscode_settings_path 2>/dev/null || true)"
  if [[ -z "$settings_path" ]]; then
    WTMUX_VSCODE_PROFILE_STATUS="not-detected"
    return 2
  fi
  WTMUX_VSCODE_SETTINGS_RESOLVED_PATH="$settings_path"
  if output="$(python3 "$(wtmux_vscode_profile_tool)" configure --path "$settings_path" --distro "$distro" 2>/dev/null)"; then
    :
  else
    status=$?
    if (( status == 3 )); then
      WTMUX_VSCODE_PROFILE_STATUS="profile-unknown"
      return 3
    fi
    WTMUX_VSCODE_PROFILE_STATUS="error"
    return 1
  fi
  WTMUX_VSCODE_PROFILE_STATUS="${output%%$'\t'*}"
  return 0
}

wtmux_vscode_managed_profile_status() {
  local settings_path=""
  local output=""
  local status=0

  WTMUX_VSCODE_PROFILE_STATUS=""
  settings_path="$(wtmux_vscode_settings_path 2>/dev/null || true)"
  if [[ -z "$settings_path" || ! -f "$settings_path" ]]; then
    WTMUX_VSCODE_PROFILE_STATUS="not-detected"
    return 2
  fi
  WTMUX_VSCODE_SETTINGS_RESOLVED_PATH="$settings_path"
  if output="$(python3 "$(wtmux_vscode_profile_tool)" status --path "$settings_path" 2>/dev/null)"; then
    :
  else
    status=$?
    if (( status == 3 )); then
      WTMUX_VSCODE_PROFILE_STATUS="profile-unknown"
      return 3
    fi
    WTMUX_VSCODE_PROFILE_STATUS="error"
    return 1
  fi
  WTMUX_VSCODE_PROFILE_STATUS="${output%%$'\t'*}"
  return 0
}

wtmux_vscode_persistence_status() {
  local settings_path=""

  WTMUX_VSCODE_PERSISTENCE_STATUS="default"
  settings_path="$(wtmux_vscode_settings_path 2>/dev/null || true)"
  if [[ -z "$settings_path" || ! -f "$settings_path" ]]; then
    WTMUX_VSCODE_PERSISTENCE_STATUS="not-detected"
    return 2
  fi
  if grep -Eq '"terminal\.integrated\.enablePersistentSessions"[[:space:]]*:[[:space:]]*false([[:space:],}]|$)' "$settings_path"; then
    WTMUX_VSCODE_PERSISTENCE_STATUS="disabled"
    return 1
  fi
  if grep -Eq '"terminal\.integrated\.persistentSessionReviveProcess"[[:space:]]*:[[:space:]]*"never"' "$settings_path"; then
    WTMUX_VSCODE_PERSISTENCE_STATUS="revive-never"
    return 1
  fi
  if grep -Eq '"terminal\.integrated\.enablePersistentSessions"[[:space:]]*:[[:space:]]*true([[:space:],}]|$)' "$settings_path"; then
    WTMUX_VSCODE_PERSISTENCE_STATUS="enabled"
  fi
  return 0
}

wtmux_vscode_windows_cli() {
  local candidates=()
  local candidate=""

  if [[ -n "${WTMUX_VSCODE_CLI:-}" ]]; then
    [[ -x "$WTMUX_VSCODE_CLI" || -f "$WTMUX_VSCODE_CLI" ]] || return 1
    printf '%s\n' "$WTMUX_VSCODE_CLI"
    return 0
  fi
  shopt -s nullglob
  candidates=(
    /mnt/c/Users/*/AppData/Local/Programs/Microsoft\ VS\ Code/Code.exe
    /mnt/c/Program\ Files/Microsoft\ VS\ Code/Code.exe
    /mnt/c/Users/*/AppData/Local/Programs/Microsoft\ VS\ Code/bin/code
    /mnt/c/Program\ Files/Microsoft\ VS\ Code/bin/code
  )
  shopt -u nullglob
  for candidate in "${candidates[@]}"; do
    [[ -f "$candidate" ]] || continue
    printf '%s\n' "$candidate"
      return 0
  done
  if command -v code.cmd >/dev/null 2>&1; then
    command -v code.cmd
    return 0
  fi
  return 1
}

wtmux_vscode_cli_run() {
  local cli="$1"
  shift
  local code_cmd=""
  local code_cmd_windows=""
  local cmd_exe="/mnt/c/Windows/System32/cmd.exe"
  local argument=""
  local converted=""
  local converted_arguments=()

  if [[ "$cli" == */Code.exe ]]; then
    code_cmd="${cli%/Code.exe}/bin/code.cmd"
    [[ -f "$code_cmd" && -f "$cmd_exe" ]] || return 1
    code_cmd_windows="$(wslpath -w "$code_cmd" 2>/dev/null || true)"
    [[ -n "$code_cmd_windows" ]] || return 1
    for argument in "$@"; do
      converted="$argument"
      if [[ "$argument" == /* && -e "$argument" ]]; then
        converted="$(wslpath -w "$argument" 2>/dev/null || printf '%s\n' "$argument")"
      fi
      converted_arguments+=("$converted")
    done
    if [[ "$(wtmux_detect_platform)" == "wsl" && ! -e /proc/sys/fs/binfmt_misc/WSLInterop && -x /init ]]; then
      /init "$cmd_exe" /d /c call "$code_cmd_windows" "${converted_arguments[@]}"
    else
      "$cmd_exe" /d /c call "$code_cmd_windows" "${converted_arguments[@]}"
    fi
    return
  fi

  if [[ "$(wtmux_detect_platform)" == "wsl" && "$cli" == /mnt/* && ( "$cli" == *.exe || "$cli" == *.cmd ) && ! -e /proc/sys/fs/binfmt_misc/WSLInterop && -x /init ]]; then
    /init "$cli" "$@"
  else
    "$cli" "$@"
  fi
}

wtmux_vscode_companion_expected_version() {
  python3 -c '
import json
import pathlib
import sys
value = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")).get("version", "")
if not isinstance(value, str) or not value:
    raise SystemExit(2)
print(value)
' "${WTMUX_REPO_ROOT}/vscode/wtmux-image-paste/package.json"
}

wtmux_vscode_companion_status() {
  local cli=""
  local extensions=""
  local expected_version=""

  WTMUX_VSCODE_COMPANION_STATUS=""
  WTMUX_VSCODE_CLI_RESOLVED_PATH=""
  expected_version="$(wtmux_vscode_companion_expected_version 2>/dev/null || true)"
  if [[ -z "$expected_version" ]]; then
    WTMUX_VSCODE_COMPANION_STATUS="source-missing"
    return 2
  fi
  cli="$(wtmux_vscode_windows_cli 2>/dev/null || true)"
  if [[ -z "$cli" ]]; then
    WTMUX_VSCODE_COMPANION_STATUS="cli-not-detected"
    return 2
  fi
  WTMUX_VSCODE_CLI_RESOLVED_PATH="$cli"
  if ! extensions="$(wtmux_vscode_cli_run "$cli" --list-extensions --show-versions 2>/dev/null)"; then
    WTMUX_VSCODE_COMPANION_STATUS="cli-unavailable"
    return 2
  fi
  extensions="${extensions//$'\r'/}"
  if grep -Fiqx "wtmux.wtmux-image-paste@${expected_version}" <<<"$extensions"; then
    WTMUX_VSCODE_COMPANION_STATUS="installed"
    return 0
  fi
  if grep -Eiq '^wtmux\.wtmux-image-paste(@|$)' <<<"$extensions"; then
    WTMUX_VSCODE_COMPANION_STATUS="outdated"
    return 1
  fi
  WTMUX_VSCODE_COMPANION_STATUS="missing"
  return 1
}

wtmux_vscode_install_companion() {
  local cli=""
  local package_dir="${WTMUX_REPO_ROOT}/vscode/wtmux-image-paste"
  local temp_dir=""
  local temp_parent="${TMPDIR:-/tmp}"
  local vsix_path=""
  local package_command=()

  if wtmux_vscode_companion_status; then
    return 0
  fi
  cli="$WTMUX_VSCODE_CLI_RESOLVED_PATH"
  [[ -n "$cli" ]] || return 2
  [[ -f "${package_dir}/package.json" && -f "${package_dir}/src/extension.js" ]] || {
    WTMUX_VSCODE_COMPANION_STATUS="source-missing"
    return 2
  }
  command -v npx >/dev/null 2>&1 || {
    WTMUX_VSCODE_COMPANION_STATUS="packager-missing"
    return 2
  }
  if [[ "$cli" == /mnt/*/Users/*/AppData/* ]]; then
    temp_parent="${cli%%/AppData/*}/AppData/Local/Temp"
    mkdir -p "$temp_parent" 2>/dev/null || temp_parent="${TMPDIR:-/tmp}"
  fi
  temp_dir="$(mktemp -d "${temp_parent}/wtmux-vscode.XXXXXX")" || {
    WTMUX_VSCODE_COMPANION_STATUS="package-error"
    return 1
  }
  vsix_path="${temp_dir}/wtmux-companion.vsix"
  package_command=(npx --yes @vscode/vsce@3.6.2 package --out "$vsix_path")
  if ! (
    cd "$package_dir"
    "${package_command[@]}" >/dev/null 2>&1
  ); then
    WTMUX_VSCODE_COMPANION_STATUS="package-error"
    [[ "$(basename "$temp_dir")" == wtmux-vscode.* ]] && rm -rf -- "$temp_dir"
    return 1
  fi
  if ! wtmux_vscode_cli_run "$cli" --install-extension "$vsix_path" --force >/dev/null 2>&1; then
    WTMUX_VSCODE_COMPANION_STATUS="install-error"
    [[ "$(basename "$temp_dir")" == wtmux-vscode.* ]] && rm -rf -- "$temp_dir"
    return 1
  fi
  [[ "$(basename "$temp_dir")" == wtmux-vscode.* ]] && rm -rf -- "$temp_dir"
  wtmux_vscode_companion_status
}
