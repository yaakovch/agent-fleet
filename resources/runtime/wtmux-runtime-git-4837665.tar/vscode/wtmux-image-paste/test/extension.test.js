const assert = require('assert');
const Module = require('module');

function configFrom(values) {
  return {
    get(key, defaultValue) {
      return Object.prototype.hasOwnProperty.call(values, key) ? values[key] : defaultValue;
    }
  };
}

const fakeVscode = {
  workspace: {
    getConfiguration() {
      return configFrom({});
    }
  },
  window: {
    activeTerminal: null,
    showInformationMessage() {},
    showErrorMessage() {}
  },
  env: {
    clipboard: {
      writes: [],
      async writeText(value) {
        this.writes.push(value);
      }
    }
  },
  commands: {
    registerCommand() {
      return { dispose() {} };
    }
  }
};

const originalLoad = Module._load;
Module._load = function load(request, parent, isMain) {
  if (request === 'vscode') {
    return fakeVscode;
  }
  return originalLoad.call(this, request, parent, isMain);
};

const extension = require('../src/extension')._test;
Module._load = originalLoad;

async function testParseHostPath() {
  assert.strictEqual(
    extension.parseHostPath('[wtmux][warn] stale session\n.wtmux/images/foo.png\n'),
    '.wtmux/images/foo.png'
  );
  assert.throws(
    () => extension.parseHostPath('not a path\n'),
    /wtmux did not return a host image path/
  );
}

async function testWindowsPathConversion() {
  const calls = [];
  const runProcess = async (command, args) => {
    calls.push({ command, args });
    return { stdout: '/mnt/c/Temp/A B/image.png\n', stderr: '' };
  };

  const sourcePath = await extension.sourcePathForWtmux('C:\\Temp\\A B\\image.png', {
    config: configFrom({ wslDistro: 'Ubuntu' }),
    platform: 'win32',
    runProcess
  });

  assert.strictEqual(sourcePath, '/mnt/c/Temp/A B/image.png');
  assert.deepStrictEqual(calls, [
    {
      command: 'wsl.exe',
      args: ['-d', 'Ubuntu', '--', 'wslpath', '-a', 'C:\\Temp\\A B\\image.png']
    }
  ]);
}

async function testDirectWslModeForcesWindowsPathConversion() {
  let converted = false;
  const runProcess = async () => {
    converted = true;
    return { stdout: '/mnt/c/Temp/image.png\n', stderr: '' };
  };

  const sourcePath = await extension.sourcePathForWtmux('C:\\Temp\\image.png', {
    config: configFrom({
      convertWindowsPathForWsl: false,
      runWtmuxInWslOnWindows: true
    }),
    platform: 'win32',
    runProcess
  });

  assert.strictEqual(converted, true);
  assert.strictEqual(sourcePath, '/mnt/c/Temp/image.png');
}

async function testNativeWindowsModeCanSkipPathConversion() {
  let converted = false;
  const sourcePath = await extension.sourcePathForWtmux('C:\\Temp\\image.png', {
    config: configFrom({
      convertWindowsPathForWsl: false,
      runWtmuxInWslOnWindows: false
    }),
    platform: 'win32',
    runProcess: async () => {
      converted = true;
      return { stdout: '/mnt/c/Temp/image.png\n', stderr: '' };
    }
  });

  assert.strictEqual(converted, false);
  assert.strictEqual(sourcePath, 'C:\\Temp\\image.png');
}

async function testWindowsWslInvocationQuotesBashArguments() {
  const invocation = extension.buildWtmuxImageSendInvocation(
    'wtmux',
    "/mnt/c/Users/O'Neil/image one.png",
    configFrom({ wslDistro: 'Ubuntu' }),
    'win32'
  );

  assert.strictEqual(invocation.command, 'wsl.exe');
  assert.deepStrictEqual(invocation.args.slice(0, 5), ['-d', 'Ubuntu', '--', 'bash', '-lc']);
  assert.strictEqual(
    invocation.args[5],
    "'wtmux' image send '/mnt/c/Users/O'\\''Neil/image one.png'"
  );
  assert.deepStrictEqual(invocation.options, { shell: false });
}

async function testWindowsShimFallbackInvocation() {
  const invocation = extension.buildWtmuxImageSendInvocation(
    'wtmux.cmd',
    '/mnt/c/Temp/image.png',
    configFrom({ runWtmuxInWslOnWindows: false }),
    'win32'
  );

  assert.strictEqual(invocation.command, 'wtmux.cmd');
  assert.deepStrictEqual(invocation.args, ['image', 'send', '/mnt/c/Temp/image.png']);
  assert.deepStrictEqual(invocation.options, { shell: true });
}

async function testSendImageToHostUsesDirectWslOnWindows() {
  const calls = [];
  const runProcess = async (command, args, options = {}) => {
    calls.push({ command, args, options });
    if (args.includes('wslpath')) {
      return { stdout: '/mnt/c/Temp/A B/image.png\n', stderr: '' };
    }
    return { stdout: '[wtmux][warn] stale session\n.wtmux/images/sent.png\n', stderr: '' };
  };

  const hostPath = await extension.sendImageToHost('C:\\Temp\\A B\\image.png', {
    config: configFrom({
      convertWindowsPathForWsl: true,
      runWtmuxInWslOnWindows: true,
      wslDistro: 'Ubuntu',
      wtmuxPath: 'wtmux'
    }),
    platform: 'win32',
    runProcess
  });

  assert.strictEqual(hostPath, '.wtmux/images/sent.png');
  assert.strictEqual(calls.length, 2);
  assert.strictEqual(calls[1].command, 'wsl.exe');
  assert.deepStrictEqual(calls[1].args.slice(0, 5), ['-d', 'Ubuntu', '--', 'bash', '-lc']);
  assert.match(calls[1].args[5], /^'wtmux' image send '/);
}

async function testInsertPathOrClipboardFallback() {
  const sent = [];
  const terminal = {
    sendText(text, shouldExecute) {
      sent.push({ text, shouldExecute });
    }
  };

  const inserted = await extension.insertPathOrFallback('.wtmux/images/inserted.png', {
    config: configFrom({ insertIntoTerminal: true }),
    terminal,
    vscode: fakeVscode
  });
  assert.strictEqual(inserted, 'inserted');
  assert.deepStrictEqual(sent, [
    { text: '.wtmux/images/inserted.png', shouldExecute: false }
  ]);

  fakeVscode.env.clipboard.writes = [];
  const copied = await extension.insertPathOrFallback('.wtmux/images/copied.png', {
    config: configFrom({ insertIntoTerminal: false }),
    terminal,
    vscode: fakeVscode
  });
  assert.strictEqual(copied, 'copied');
  assert.deepStrictEqual(fakeVscode.env.clipboard.writes, ['.wtmux/images/copied.png']);
}

async function testValidatedOpenUriBuildsDirectWslTerminal() {
  const target = extension.parseOpenUri({
    authority: 'wtmux.wtmux-image-paste',
    path: '/open',
    query: 'host=work-m-ubuntu&project=agent-fleet&session=wtmux-agent-fleet-1&distro=Ubuntu'
  });
  assert.deepStrictEqual(extension.buildAttachTerminalOptions(target), {
    shellPath: 'wsl.exe',
    shellArgs: [
      '-d', 'Ubuntu', '--cd', '~', '--', '.local/bin/wtmux', 'vscode', 'terminal',
      '--host', 'work-m-ubuntu', '--project', 'agent-fleet',
      '--session', 'wtmux-agent-fleet-1'
    ]
  });
  assert.throws(
    () => extension.parseOpenUri({ authority: 'evil.extension', path: '/open', query: '' }),
    /Unsupported wtmux URI/
  );
}

function restorationState() {
  return {
    lastManagedTitle: new Map(),
    handledNonces: new Set(),
    knownTerminals: new Set(),
    launchedTerminalTitles: new Map(),
    replacingTerminals: new Set(),
    terminalProcessIds: new Map(),
    persistedProcessBindings: new Map(),
    async persist() {}
  };
}

async function testManagedAndLegacyTitleValidation() {
  assert.strictEqual(
    extension.stableManagedTitle('wtmux · scripts:1 · work-m | Codex'),
    'wtmux · scripts:1 · work-m'
  );
  assert.strictEqual(
    extension.stableManagedTitle('wtmux · scripts:1 · work-m Windows'),
    'wtmux · scripts:1 · work-m Windows'
  );
  assert.strictEqual(extension.stableManagedTitle('wtmux · scripts'), '');
  assert.strictEqual(extension.restoreNonce('wtmux restore · 0123456789abcdef0123456789abcdef'), '0123456789abcdef0123456789abcdef');
  assert.strictEqual(extension.restoreNonce('wtmux restore · bad'), '');
  assert.strictEqual(extension.legacyManagedTitle('scripts:1 | Codex'), 'scripts:1');
  assert.strictEqual(extension.legacyManagedTitle('bash'), '');
}

async function testRestoreResponseInvocations() {
  const config = configFrom({ wslDistro: 'Ubuntu', wtmuxPath: '.local/bin/wtmux' });
  const nonce = '0123456789abcdef0123456789abcdef';
  const restore = extension.buildRestoreResponseInvocation(
    nonce,
    'wtmux · scripts:1 · work-m | Codex',
    config
  );
  assert.strictEqual(restore.command, 'wsl.exe');
  assert.deepStrictEqual(restore.args.slice(0, 8), [
    '-d', 'Ubuntu', '--cd', '~', '--', '.local/bin/wtmux', 'vscode', 'respond'
  ]);
  assert.deepStrictEqual(restore.args.slice(8, 12), [
    '--nonce', nonce, '--mode', 'restore'
  ]);
  assert.strictEqual(
    Buffer.from(restore.args[13], 'base64').toString('utf8'),
    'wtmux · scripts:1 · work-m'
  );

  const fresh = extension.buildRestoreResponseInvocation(nonce, '', config);
  assert.deepStrictEqual(fresh.args.slice(-4), ['--nonce', nonce, '--mode', 'new']);
  assert.throws(
    () => extension.buildRestoreResponseInvocation('bad', '', config),
    /nonce is invalid/i
  );
}

async function testRestorationTracksTerminalObjectAndRespondsOnce() {
  const terminal = {
    name: 'wtmux · scripts:1 · work-m | Codex',
    processId: Promise.resolve(1234)
  };
  const state = restorationState();
  const calls = [];
  const deps = {
    config: configFrom({ wslDistro: 'Ubuntu' }),
    async runProcess(command, args, options) {
      calls.push({ command, args, options });
      return { stdout: '', stderr: '' };
    }
  };

  await extension.inspectTerminalRestoration([terminal], state, deps);
  assert.strictEqual(state.lastManagedTitle.get(terminal), 'wtmux · scripts:1 · work-m');
  terminal.name = 'wtmux restore · 0123456789abcdef0123456789abcdef';
  await extension.inspectTerminalRestoration([terminal], state, deps);
  await extension.inspectTerminalRestoration([terminal], state, deps);
  assert.strictEqual(calls.length, 1);
  assert.ok(calls[0].args.includes('restore'));
  assert.strictEqual(
    Buffer.from(calls[0].args[calls[0].args.indexOf('--title-b64') + 1], 'base64').toString('utf8'),
    'wtmux · scripts:1 · work-m'
  );

  await extension.inspectTerminalRestoration([], state, deps);
  assert.strictEqual(state.lastManagedTitle.has(terminal), false);
  assert.strictEqual(state.persistedProcessBindings.has('1234'), false);
}

async function testFreshAndUnrelatedTerminalsFailClosed() {
  const fresh = {
    name: 'wtmux restore · fedcba9876543210fedcba9876543210',
    processId: Promise.resolve(2345)
  };
  const unrelated = { name: 'bash', processId: Promise.resolve(3456) };
  const state = restorationState();
  const calls = [];
  await extension.inspectTerminalRestoration([fresh, unrelated], state, {
    config: configFrom({ wslDistro: 'Ubuntu' }),
    async runProcess(command, args) {
      calls.push({ command, args });
      return { stdout: '', stderr: '' };
    }
  });
  assert.strictEqual(calls.length, 1);
  assert.deepStrictEqual(calls[0].args.slice(-4), [
    '--nonce', 'fedcba9876543210fedcba9876543210', '--mode', 'new'
  ]);
}

async function testRestorationRecoversTitleByPersistentProcessIdentity() {
  const first = {
    name: 'wtmux · scripts:1 · work-m',
    processId: Promise.resolve(4567)
  };
  const firstState = restorationState();
  await extension.inspectTerminalRestoration([first], firstState, {
    config: configFrom({})
  });
  const serialized = extension.serializedTerminalProcessBindings(
    firstState.persistedProcessBindings
  );
  assert.deepStrictEqual(serialized.map(item => [item.processId, item.title]), [
    ['4567', 'wtmux · scripts:1 · work-m']
  ]);

  const restored = {
    name: 'wsl',
    processId: Promise.resolve(4567)
  };
  const secondState = restorationState();
  secondState.persistedProcessBindings = extension.loadTerminalProcessBindings({
    get() {
      return serialized;
    }
  });
  await extension.inspectTerminalRestoration([restored], secondState, {
    config: configFrom({})
  });
  assert.strictEqual(
    secondState.lastManagedTitle.get(restored),
    'wtmux · scripts:1 · work-m'
  );

  restored.name = 'wtmux restore · 0123456789abcdef0123456789abcdef';
  const calls = [];
  await extension.inspectTerminalRestoration([restored], secondState, {
    config: configFrom({ wslDistro: 'Ubuntu' }),
    async runProcess(command, args) {
      calls.push({ command, args });
      return { stdout: '', stderr: '' };
    }
  });
  assert.strictEqual(calls.length, 1);
  assert.strictEqual(
    Buffer.from(calls[0].args[calls[0].args.indexOf('--title-b64') + 1], 'base64').toString('utf8'),
    'wtmux · scripts:1 · work-m'
  );
}

async function testRevivedTerminalIsReplacedOnlyAfterExactResolution() {
  const calls = [];
  const created = [];
  let disposed = false;
  const terminal = {
    name: 'wsl',
    processId: Promise.resolve(5678),
    dispose() {
      disposed = true;
    }
  };
  const replacement = {
    processId: Promise.resolve(6789),
    show(preserveFocus) {
      calls.push({ preserveFocus });
    },
    dispose() {
      throw new Error('valid replacement must not be disposed');
    }
  };
  const targetVscode = {
    workspace: {
      getConfiguration() {
        return configFrom({ wslDistro: 'Ubuntu', wtmuxPath: 'custom/wtmux' });
      }
    },
    window: {
      activeTerminal: terminal,
      createTerminal(options) {
        created.push(options);
        return replacement;
      }
    }
  };

  const result = await extension.replaceRevivedManagedTerminal(
    terminal,
    'wtmux · scripts:1 · work-m',
    {
      vscode: targetVscode,
      async runProcess(command, args) {
        calls.push({ command, args });
        return {
          stdout: JSON.stringify({
            status: 'resolved',
            hostId: 'work-m-ubuntu',
            project: 'scripts',
            session: 'wtmux-scripts-1'
          })
        };
      }
    }
  );
  assert.strictEqual(result, replacement);
  assert.strictEqual(disposed, true);
  assert.deepStrictEqual(created, [{
    shellPath: 'wsl.exe',
    shellArgs: [
      '-d', 'Ubuntu', '--cd', '~', '--', 'custom/wtmux', 'vscode', 'terminal',
      '--host', 'work-m-ubuntu', '--project', 'scripts', '--session', 'wtmux-scripts-1'
    ],
    location: { parentTerminal: terminal }
  }]);
  assert.deepStrictEqual(calls[1], { preserveFocus: false });
}

async function testExactManagedLaunchDiscoversWindowsTitleWithoutOscName() {
  const terminal = {
    name: 'wsl',
    processId: Promise.resolve(7890),
    creationOptions: {
      shellPath: 'C:\\Windows\\System32\\wsl.exe',
      shellArgs: [
        '-d', 'Ubuntu', '--cd', '~', '--', '.local/bin/wtmux', 'vscode', 'terminal',
        '--host', 'gaming-desktop_windows',
        '--project', 'scripts',
        '--session', 'wtmux-win-scripts-1'
      ]
    }
  };
  assert.deepStrictEqual(extension.managedLaunchTarget(terminal.creationOptions), {
    host: 'gaming-desktop_windows',
    project: 'scripts',
    session: 'wtmux-win-scripts-1',
    distro: 'Ubuntu',
    wtmuxPath: '.local/bin/wtmux'
  });
  const state = restorationState();
  const calls = [];
  await extension.inspectTerminalRestoration([terminal], state, {
    config: configFrom({ wslDistro: 'Ubuntu' }),
    async resolveLaunchedTerminal(targetTerminal) {
      calls.push(targetTerminal);
      return 'wtmux · scripts:1 · gaming-desktop Windows';
    }
  });
  assert.deepStrictEqual(calls, [terminal]);
  assert.strictEqual(
    state.lastManagedTitle.get(terminal),
    'wtmux · scripts:1 · gaming-desktop Windows'
  );
  assert.strictEqual(
    state.persistedProcessBindings.get('7890').title,
    'wtmux · scripts:1 · gaming-desktop Windows'
  );

  await extension.inspectTerminalRestoration([terminal], state, {
    config: configFrom({}),
    async resolveLaunchedTerminal() {
      throw new Error('resolved exact launch must be cached by terminal object');
    }
  });
}

async function main() {
  const tests = [
    testParseHostPath,
    testWindowsPathConversion,
    testDirectWslModeForcesWindowsPathConversion,
    testNativeWindowsModeCanSkipPathConversion,
    testWindowsWslInvocationQuotesBashArguments,
    testWindowsShimFallbackInvocation,
    testSendImageToHostUsesDirectWslOnWindows,
    testInsertPathOrClipboardFallback,
    testValidatedOpenUriBuildsDirectWslTerminal,
    testManagedAndLegacyTitleValidation,
    testRestoreResponseInvocations,
    testRestorationTracksTerminalObjectAndRespondsOnce,
    testFreshAndUnrelatedTerminalsFailClosed,
    testRestorationRecoversTitleByPersistentProcessIdentity,
    testRevivedTerminalIsReplacedOnlyAfterExactResolution,
    testExactManagedLaunchDiscoversWindowsTitleWithoutOscName
  ];

  for (const test of tests) {
    await test();
  }
  console.log(`ok ${tests.length} extension tests`);
}

main().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
