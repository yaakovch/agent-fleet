const assert = require('assert');
const childProcess = require('child_process');
const fs = require('fs');
const path = require('path');
const util = require('util');
const vscode = require('vscode');

const execFile = util.promisify(childProcess.execFile);
const PHASE_PATH = path.join(__dirname, '.windows-isolated-phase.json');
const RESULT_PATH = path.join(__dirname, '.windows-isolated-result.json');
const STABLE_TITLE_PATTERN = /^(wtmux · [^|\u0000-\u001f\u007f]{1,256} · [^|\u0000-\u001f\u007f]{1,160})(?: \| .*)?$/;
const EXPECTED_TITLES = [
  'wtmux · hill:1 · gaming-desktop',
  'wtmux · hill:1 · gaming-desktop',
  'wtmux · hill:2 · gaming-desktop'
].sort();
const WINDOWS_TITLE = 'wtmux · wtmux-vscode-restore-test:1 · gaming-desktop Windows';
const EXPECTED_CLIENT_INCREMENTS = {
  'wtmux-hill-1': 2,
  'wtmux-hill-2': 1,
  'wtmux-win-wtmux-vscode-restore-test-1': 1
};
const TARGETS = [
  {
    host: 'gaming-desktop-ubuntu',
    project: 'hill',
    session: 'wtmux-hill-1',
    displayName: 'hill:1'
  },
  {
    host: 'gaming-desktop-ubuntu',
    project: 'hill',
    session: 'wtmux-hill-2',
    displayName: 'hill:2'
  },
  {
    host: 'gaming-desktop_windows',
    project: 'wtmux-vscode-restore-test',
    session: 'wtmux-win-wtmux-vscode-restore-test-1',
    displayName: 'wtmux-vscode-restore-test:1'
  },
  {
    host: 'gaming-desktop-ubuntu',
    project: 'hill',
    session: 'wtmux-hill-1',
    displayName: 'hill:1'
  }
];

function sleep(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}

function stableTitle(terminal) {
  const match = STABLE_TITLE_PATTERN.exec(terminal && terminal.name);
  return match ? match[1] : '';
}

function currentStableTitles() {
  return vscode.window.terminals.map(stableTitle).filter(Boolean).sort();
}

function matchesExpectedTitles() {
  if (vscode.window.terminals.length !== TARGETS.length) {
    return false;
  }
  const stable = currentStableTitles();
  if (JSON.stringify(stable) === JSON.stringify([...EXPECTED_TITLES, WINDOWS_TITLE].sort())) {
    return true;
  }
  return JSON.stringify(stable) === JSON.stringify(EXPECTED_TITLES)
    && vscode.window.terminals.some(terminal => terminal.name === 'wsl');
}

async function waitFor(predicate, message, timeoutMilliseconds = 30000) {
  const deadline = Date.now() + timeoutMilliseconds;
  while (Date.now() < deadline) {
    if (await predicate()) {
      return;
    }
    await sleep(25);
  }
  const terminals = await Promise.all(vscode.window.terminals.map(async terminal => {
    const creationOptions = terminal.creationOptions || {};
    return {
      name: terminal.name,
      processId: await terminal.processId,
      shellPath: creationOptions.shellPath || '',
      shellArgs: Array.isArray(creationOptions.shellArgs) ? creationOptions.shellArgs : []
    };
  }));
  throw new Error(`${message}; terminals=${JSON.stringify(terminals)}`);
}

function terminalOptions(target, location) {
  const options = {
    shellPath: 'wsl.exe',
    shellArgs: [
      '-d', 'Ubuntu', '--cd', '~', '--', '.local/bin/wtmux', 'vscode', 'terminal',
      '--host', target.host, '--project', target.project, '--session', target.session
    ]
  };
  if (location) {
    options.location = location;
  }
  return options;
}

async function liveInventory() {
  const result = await execFile('wsl.exe', [
    '-d', 'Ubuntu', '--cd', '~', '--',
    '.local/bin/wtmux-host', 'sessions', '--all', '--identity'
  ], {
    encoding: 'utf8',
    timeout: 15000,
    windowsHide: true
  });
  return result.stdout
    .split(/\r?\n/)
    .filter(Boolean)
    .map(line => line.split('\t').slice(0, 3).join('\t'))
    .sort();
}

async function validateTitleResolver(title) {
  let resolved = false;
  await waitFor(async () => {
    try {
      const result = await execFile('wsl.exe', [
        '-d', 'Ubuntu', '--cd', '~', '--',
        '.local/bin/wtmux', 'vscode', 'resolve-title',
        '--title-b64', Buffer.from(title, 'utf8').toString('base64'),
        '--json'
      ], {
        encoding: 'utf8',
        timeout: 15000,
        windowsHide: true
      });
      resolved = JSON.parse(result.stdout).status === 'resolved';
      return resolved;
    } catch (_) {
      return false;
    }
  }, `title resolver did not confirm ${title}`, 15000);
  assert.strictEqual(resolved, true);
}

async function tmuxClientCounts() {
  const result = await execFile('wsl.exe', [
    '-d', 'Ubuntu', '--cd', '~', '--',
    'bash', '-lc', "tmux list-clients -F '#{session_name}'"
  ], {
    encoding: 'utf8',
    timeout: 15000,
    windowsHide: true
  });
  const counts = {};
  for (const session of result.stdout.split(/\r?\n/).filter(Boolean)) {
    counts[session] = (counts[session] || 0) + 1;
  }
  return counts;
}

function hasExpectedClientIncrements(baseline, current) {
  return Object.entries(EXPECTED_CLIENT_INCREMENTS).every(
    ([session, increment]) => (current[session] || 0) === (baseline[session] || 0) + increment
  );
}

async function waitForExactClients(baseline, message) {
  await waitFor(
    async () => hasExpectedClientIncrements(baseline, await tmuxClientCounts()),
    message,
    30000
  );
}

async function sortedTerminalProcessIds() {
  return (await Promise.all(vscode.window.terminals.map(terminal => terminal.processId)))
    .filter(processId => Number.isSafeInteger(processId) && processId > 0)
    .sort((left, right) => left - right);
}

async function hasRestoredProcesses(expectedProcessIds) {
  if (vscode.window.terminals.length !== TARGETS.length) {
    return false;
  }
  return JSON.stringify(await sortedTerminalProcessIds()) === JSON.stringify(expectedProcessIds);
}

async function hasReplacementProcesses(originalProcessIds) {
  if (!matchesExpectedTitles()) {
    return false;
  }
  const current = await sortedTerminalProcessIds();
  return current.length === TARGETS.length
    && current.every(processId => !originalProcessIds.includes(processId));
}

async function activateCompanion() {
  const extension = vscode.extensions.getExtension('wtmux.wtmux-image-paste');
  assert.ok(extension, 'wtmux Companion was not loaded in the isolated extension host');
  await extension.activate();
}

async function seedPersistentTerminals() {
  assert.strictEqual(vscode.window.terminals.length, 0, 'isolated seed profile was not empty');
  const inventory = await liveInventory();
  const clientBaseline = await tmuxClientCounts();
  await validateTitleResolver('wtmux · hill:1 · gaming-desktop');
  await validateTitleResolver(WINDOWS_TITLE);
  const first = vscode.window.createTerminal(terminalOptions(TARGETS[0]));
  first.show();
  const split = vscode.window.createTerminal(terminalOptions(
    TARGETS[1],
    { parentTerminal: first }
  ));
  split.show();
  for (const target of TARGETS.slice(2)) {
    const terminal = vscode.window.createTerminal(terminalOptions(target));
    terminal.show();
  }
  await waitFor(matchesExpectedTitles, 'managed terminals did not reach their stable titles', 45000);
  await waitForExactClients(clientBaseline, 'managed terminals did not attach to their exact tmux sessions');
  assert.deepStrictEqual(await liveInventory(), inventory, 'opening duplicate attachments changed live tmux identity');
  const processIds = await sortedTerminalProcessIds();
  assert.strictEqual(processIds.length, TARGETS.length, 'managed terminals did not expose stable process identities');
  await sleep(500);
  await fs.promises.writeFile(
    PHASE_PATH,
    JSON.stringify({ inventory, clientBaseline, processIds }) + '\n',
    { flag: 'wx' }
  );
  console.log('WTMUX_VSCODE_ISOLATED_PHASE_1_OK');
  void vscode.commands.executeCommand('workbench.action.reloadWindow');
}

async function validateReopenAndPtyRestart() {
  const phase = JSON.parse(await fs.promises.readFile(PHASE_PATH, 'utf8'));
  await waitFor(
    async () => hasRestoredProcesses(phase.processIds)
      || hasReplacementProcesses(phase.processIds),
    'normal VS Code reopen did not revive or replace the exact managed terminals',
    45000
  );
  assert.deepStrictEqual(await liveInventory(), phase.inventory, 'normal reopen changed live tmux identity');
  await waitFor(
    () => hasReplacementProcesses(phase.processIds),
    'the companion did not replace revived terminals with exact managed launchers',
    45000
  );
  await waitForExactClients(
    phase.clientBaseline,
    'managed replacement terminals attached to the wrong tmux sessions'
  );
  await sleep(500);

  const first = vscode.window.terminals[0];
  first.show();
  const beforeRelaunch = await sortedTerminalProcessIds();
  await vscode.commands.executeCommand('workbench.action.terminal.relaunch');
  await waitFor(
    async () => matchesExpectedTitles()
      && JSON.stringify(await sortedTerminalProcessIds()) !== JSON.stringify(beforeRelaunch),
    'single-terminal relaunch did not return to its exact managed target',
    45000
  );
  await waitForExactClients(phase.clientBaseline, 'single-terminal relaunch attached to the wrong tmux session');

  await vscode.commands.executeCommand('workbench.action.terminal.restartPtyHost');
  await waitFor(
    matchesExpectedTitles,
    'isolated PTY host restart did not restore the managed terminal targets',
    45000
  );
  await waitForExactClients(phase.clientBaseline, 'PTY host restart attached to the wrong tmux sessions');
  assert.deepStrictEqual(await liveInventory(), phase.inventory, 'PTY host restart changed live tmux identity');

  for (const terminal of [...vscode.window.terminals]) {
    terminal.dispose();
  }
  await waitFor(() => vscode.window.terminals.length === 0, 'isolated terminals did not close');
  await fs.promises.unlink(PHASE_PATH);
  await fs.promises.writeFile(
    RESULT_PATH,
    JSON.stringify({
      status: 'passed',
      scenarios: [
        'tabs',
        'split',
        'duplicate',
        'reopen',
        'relaunch',
        'pty-host-restart',
        'exact-tmux-clients'
      ],
      inventory: phase.inventory
    }) + '\n',
    { flag: 'wx' }
  );
  console.log('WTMUX_VSCODE_ISOLATED_PHASE_2_OK');
}

async function run() {
  await activateCompanion();
  if (fs.existsSync(RESULT_PATH)) {
    throw new Error('isolated result marker already exists');
  }
  if (fs.existsSync(PHASE_PATH)) {
    await validateReopenAndPtyRestart();
  } else {
    await seedPersistentTerminals();
  }
}

module.exports = { run };
