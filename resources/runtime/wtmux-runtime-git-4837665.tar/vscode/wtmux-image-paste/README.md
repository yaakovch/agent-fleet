# wtmux Companion

The companion restores managed wtmux terminal tabs in desktop Windows VS Code
and keeps the existing clipboard-image workflow.

When VS Code cannot revive an old terminal PTY, the managed profile starts a
bounded wtmux restore handshake. The extension remembers each terminal's last
strict `wtmux · project:N · host` title, including across a VS Code extension
host reload by matching the revived terminal process. It returns that title
through WSL without typing control data into the terminal. wtmux then confirms
the target against live host inventory before attaching.

Use **wtmux: Migrate Legacy Terminal** to open a managed replacement for a
uniquely resolvable older `project:N` terminal. The old terminal is never
closed automatically.

VS Code companion extension for sending a client clipboard image to the active
`wtmux` host project.

## Workflow

1. Attach to a project through `wtmux`.
2. Copy a screenshot or snip on the VS Code client.
3. Focus the Codex terminal.
4. Run `wtmux: Paste Image To Host` or press `Ctrl+Alt+V`.
5. The extension sends the image with `wtmux image send` and inserts a path like:

```text
.wtmux/images/2026-04-27T10-55-12-a1b2c3d4.png
```

The path is inserted without pressing Enter.

## Requirements

- The extension runs on the VS Code UI/client side via `"extensionKind": ["ui"]`.
- On Linux/macOS clients, `wtmux` must be runnable on the VS Code client `PATH`.
- On Windows, the extension defaults to calling `wsl.exe` directly and running
  `wtmux` inside WSL, so `wtmux` must be installed in that distro. Set
  `wtmuxImagePaste.wslDistro` if the default WSL distro is not the one that has
  `wtmux` installed.
- On Linux, install `wl-clipboard` for Wayland or `xclip` for X11 clipboard image
  capture.
- On macOS, install `pngpaste` for clipboard image capture.

If you prefer the older Windows shim flow, install the included `wtmux.cmd` from
`windows-install-shim.ps1`, set `wtmuxImagePaste.runWtmuxInWslOnWindows` to
`false`, and point `wtmuxImagePaste.wtmuxPath` at the shim if it is not on PATH.

## Development Install

During early use, run this extension from a VS Code extension development host or
package it with `vsce`/`@vscode/vsce` and install the generated VSIX:

```bash
cd vscode/wtmux-image-paste
npm run check
npm test
npx @vscode/vsce@3.6.2 package
```

Then install the generated `.vsix` from VS Code's `Extensions: Install from
VSIX...` command.

## Settings

- `wtmuxImagePaste.wtmuxPath`: wtmux executable, defaulting to
  `.local/bin/wtmux`. In default Windows mode this is resolved from the WSL
  home; in shim mode it is resolved on Windows.
- `wtmuxImagePaste.insertIntoTerminal`: insert the host path into the active
  terminal without execution.
- `wtmuxImagePaste.showSuccessNotification`: show a success notification.
- `wtmuxImagePaste.convertWindowsPathForWsl`: convert temporary Windows image
  paths to WSL paths before calling `wtmux`.
- `wtmuxImagePaste.runWtmuxInWslOnWindows`: on Windows, run `wtmux` through
  `wsl.exe` directly instead of using a Windows shim.
- `wtmuxImagePaste.wslDistro`: optional WSL distro used for path conversion.

## Troubleshooting

- If no host/project was recorded, attach through `wtmux` once or run
  `wtmux image send <file> --host <id> --project <name>` manually.
- If `wtmux` is not found, set `wtmuxImagePaste.wtmuxPath`.
- On Windows, also check `wtmuxImagePaste.wslDistro` if `wtmux` is installed in
  a non-default WSL distro.
- If the clipboard is not an image, the command reports an error and does not
  insert terminal text.
