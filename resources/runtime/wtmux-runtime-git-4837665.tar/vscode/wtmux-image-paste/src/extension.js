const vscode = require('vscode');
const childProcess = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const MANAGED_TITLE_PATTERN = /^wtmux · ([^|\u0000-\u001f\u007f]{1,256}) · ([^|\u0000-\u001f\u007f]{1,160})$/;
const RESTORE_TITLE_PATTERN = /^wtmux restore · ([a-f0-9]{32})$/;
const LEGACY_TITLE_PATTERN = /^([^|\u0000-\u001f\u007f]{1,220}:[0-9]+)(?: \| .*)?$/;
const RESTORE_POLL_MS = 200;
const MIGRATION_NOTICE_KEY = 'wtmux.restoreMigrationNoticeVersion';
const TERMINAL_BINDINGS_KEY = 'wtmux.restoreTerminalProcessBindings.v1';
const TERMINAL_BINDING_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000;
const TERMINAL_BINDING_LIMIT = 512;

function runProcess(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = childProcess.spawn(command, args, {
      cwd: options.cwd,
      env: options.env || process.env,
      shell: options.shell || false,
      windowsHide: true
    });
    let stdout = '';
    let stderr = '';

    if (child.stdout) {
      child.stdout.on('data', chunk => {
        stdout += chunk.toString();
      });
    }
    if (child.stderr) {
      child.stderr.on('data', chunk => {
        stderr += chunk.toString();
      });
    }
    child.on('error', reject);
    child.on('close', code => {
      if (code === 0) {
        resolve({ stdout, stderr });
      } else {
        const error = new Error(stderr.trim() || `${command} exited with status ${code}`);
        error.code = code;
        error.stdout = stdout;
        error.stderr = stderr;
        reject(error);
      }
    });
  });
}

function configValue(config, key, defaultValue) {
  if (!config || typeof config.get !== 'function') {
    return defaultValue;
  }
  return config.get(key, defaultValue);
}

function wslBaseArgs(distro) {
  const args = [];
  if (distro) {
    args.push('-d', distro);
  }
  return args;
}

function wtmuxPathFromConfig(config) {
  return configValue(config, 'wtmuxPath', '.local/bin/wtmux');
}

function buildWslWtmuxInvocation(config, args) {
  const distro = configValue(config, 'wslDistro', '');
  return {
    command: 'wsl.exe',
    args: [
      ...wslBaseArgs(distro),
      '--cd', '~', '--', wtmuxPathFromConfig(config), ...args
    ],
    options: { shell: false }
  };
}

function stableManagedTitle(rawTitle) {
  if (typeof rawTitle !== 'string' || Buffer.byteLength(rawTitle, 'utf8') > 512) {
    return '';
  }
  const stable = rawTitle.split(' | ', 1)[0];
  return MANAGED_TITLE_PATTERN.test(stable) ? stable : '';
}

function restoreNonce(rawTitle) {
  if (typeof rawTitle !== 'string') {
    return '';
  }
  const match = RESTORE_TITLE_PATTERN.exec(rawTitle);
  return match ? match[1] : '';
}

function legacyManagedTitle(rawTitle) {
  if (typeof rawTitle !== 'string' || stableManagedTitle(rawTitle) || restoreNonce(rawTitle)) {
    return '';
  }
  const match = LEGACY_TITLE_PATTERN.exec(rawTitle);
  return match ? match[1] : '';
}

function buildRestoreResponseInvocation(nonce, title, config) {
  if (!/^[a-f0-9]{32}$/.test(nonce)) {
    throw new Error('Restore nonce is invalid.');
  }
  const args = ['vscode', 'respond', '--nonce', nonce];
  if (title) {
    const stable = stableManagedTitle(title);
    if (!stable) {
      throw new Error('Managed terminal title is invalid.');
    }
    args.push('--mode', 'restore', '--title-b64', Buffer.from(stable, 'utf8').toString('base64'));
  } else {
    args.push('--mode', 'new');
  }
  return buildWslWtmuxInvocation(config, args);
}

function buildResolveTitleInvocation(title, config) {
  if (typeof title !== 'string' || !title || Buffer.byteLength(title, 'utf8') > 512) {
    throw new Error('Terminal title is invalid.');
  }
  return buildWslWtmuxInvocation(config, [
    'vscode', 'resolve-title',
    '--title-b64', Buffer.from(title, 'utf8').toString('base64'),
    '--json'
  ]);
}

function managedLaunchTarget(creationOptions) {
  if (!creationOptions || typeof creationOptions.shellPath !== 'string') {
    return null;
  }
  const shellPath = creationOptions.shellPath.replace(/\\/g, '/').toLowerCase();
  if (shellPath !== 'wsl.exe' && !shellPath.endsWith('/wsl.exe')) {
    return null;
  }
  const args = creationOptions.shellArgs;
  if (!Array.isArray(args) || args.some(value => typeof value !== 'string')) {
    return null;
  }
  const commandIndex = args.findIndex(
    (value, index) => value === 'vscode' && args[index + 1] === 'terminal'
  );
  if (commandIndex < 4) {
    return null;
  }
  let prefixIndex = 0;
  let distro = '';
  if (args[prefixIndex] === '-d' && args.length > prefixIndex + 1) {
    distro = args[prefixIndex + 1];
    prefixIndex += 2;
  }
  if (
    args[prefixIndex] !== '--cd'
    || args[prefixIndex + 1] !== '~'
    || args[prefixIndex + 2] !== '--'
    || prefixIndex + 4 !== commandIndex
  ) {
    return null;
  }
  const wtmuxPath = args[prefixIndex + 3];
  if (
    !wtmuxPath
    || wtmuxPath.startsWith('-')
    || Buffer.byteLength(wtmuxPath, 'utf8') > 512
    || /[\u0000-\u001f\u007f]/.test(wtmuxPath)
  ) {
    return null;
  }
  const values = {};
  for (let index = commandIndex + 2; index < args.length; index += 2) {
    const flag = args[index];
    const value = args[index + 1];
    if (
      !['--host', '--project', '--session'].includes(flag)
      || typeof value !== 'string'
      || Object.prototype.hasOwnProperty.call(values, flag)
    ) {
      return null;
    }
    values[flag] = value;
  }
  const host = values['--host'] || '';
  const project = values['--project'] || '';
  const session = values['--session'] || '';
  if (
    !/^[A-Za-z0-9._:-]{1,160}$/.test(host)
    || !/^[A-Za-z0-9._-]{1,128}$/.test(session)
    || !project
    || project.length > 256
    || /[\u0000-\u001f\u007f]/.test(project)
    || (distro && (distro.length > 64 || /[\u0000-\u001f\u007f]/.test(distro)))
  ) {
    return null;
  }
  return { host, project, session, distro, wtmuxPath };
}

function buildResolveTargetInvocation(target, config) {
  return buildWslWtmuxInvocation(config, [
    'vscode', 'resolve-target',
    '--host', target.host,
    '--project', target.project,
    '--session', target.session,
    '--json'
  ]);
}

async function resolveManagedLaunchTitle(terminal, deps = {}) {
  const target = managedLaunchTarget(terminal && terminal.creationOptions);
  if (!target) {
    return '';
  }
  const config = deps.config || vscode.workspace.getConfiguration('wtmuxImagePaste');
  const runProcessImpl = deps.runProcess || runProcess;
  const invocation = buildResolveTargetInvocation(target, config);
  const result = await runProcessImpl(invocation.command, invocation.args, invocation.options);
  const resolved = JSON.parse(result.stdout);
  const title = stableManagedTitle(resolved.title);
  if (
    resolved.status !== 'resolved'
    || resolved.hostId !== target.host
    || resolved.project !== target.project
    || resolved.session !== target.session
    || !title
  ) {
    throw new Error('Managed terminal launch target did not resolve exactly.');
  }
  return title;
}

async function terminalProcessId(terminal) {
  try {
    const processId = await terminal.processId;
    if (Number.isSafeInteger(processId) && processId > 0) {
      return String(processId);
    }
  } catch (_) {
    // A terminal can close while its process ID promise is being resolved.
  }
  return '';
}

function loadTerminalProcessBindings(storage, now = Date.now()) {
  if (!storage || typeof storage.get !== 'function') {
    return new Map();
  }
  const raw = storage.get(TERMINAL_BINDINGS_KEY, []);
  if (!Array.isArray(raw)) {
    return new Map();
  }
  const bindings = new Map();
  for (const item of raw.slice(0, TERMINAL_BINDING_LIMIT)) {
    if (
      !item
      || !/^[1-9][0-9]{0,19}$/.test(String(item.processId || ''))
      || !stableManagedTitle(item.title)
      || !Number.isFinite(item.updatedAt)
      || item.updatedAt > now + 60_000
      || now - item.updatedAt > TERMINAL_BINDING_MAX_AGE_MS
    ) {
      continue;
    }
    bindings.set(String(item.processId), {
      title: stableManagedTitle(item.title),
      updatedAt: item.updatedAt
    });
  }
  return bindings;
}

function serializedTerminalProcessBindings(bindings) {
  return [...bindings.entries()]
    .map(([processId, item]) => ({
      processId,
      title: item.title,
      updatedAt: item.updatedAt
    }))
    .sort((left, right) => right.updatedAt - left.updatedAt)
    .slice(0, TERMINAL_BINDING_LIMIT);
}

async function rememberTerminalBinding(terminal, title, state, now = Date.now()) {
  const stable = stableManagedTitle(title);
  if (!stable) {
    return;
  }
  state.lastManagedTitle.set(terminal, stable);
  const processId = await terminalProcessId(terminal);
  if (!processId) {
    return;
  }
  const previousProcessId = state.terminalProcessIds.get(terminal);
  const existing = state.persistedProcessBindings.get(processId);
  const shouldRefresh = !existing
    || existing.title !== stable
    || now - existing.updatedAt > 24 * 60 * 60 * 1000;
  if (previousProcessId && previousProcessId !== processId) {
    state.persistedProcessBindings.delete(previousProcessId);
  }
  state.terminalProcessIds.set(terminal, processId);
  if (!shouldRefresh && (!previousProcessId || previousProcessId === processId)) {
    return;
  }
  state.persistedProcessBindings.set(processId, { title: stable, updatedAt: now });
  if (state.persist) {
    await state.persist();
  }
}

async function recoverTerminalBinding(terminal, state) {
  if (state.lastManagedTitle.has(terminal)) {
    return state.lastManagedTitle.get(terminal);
  }
  const processId = await terminalProcessId(terminal);
  if (!processId) {
    return '';
  }
  state.terminalProcessIds.set(terminal, processId);
  const persisted = state.persistedProcessBindings.get(processId);
  if (!persisted) {
    return '';
  }
  state.lastManagedTitle.set(terminal, persisted.title);
  return persisted.title;
}

async function replaceRevivedManagedTerminal(terminal, title, deps = {}) {
  const targetVscode = deps.vscode || vscode;
  const config = deps.config || targetVscode.workspace.getConfiguration('wtmuxImagePaste');
  const runProcessImpl = deps.runProcess || runProcess;
  const invocation = buildResolveTitleInvocation(title, config);
  const result = await runProcessImpl(invocation.command, invocation.args, invocation.options);
  const resolved = JSON.parse(result.stdout);
  if (
    resolved.status !== 'resolved'
    || !resolved.hostId
    || !resolved.project
    || !resolved.session
  ) {
    throw new Error(`Revived terminal no longer resolves uniquely: ${title}`);
  }
  const replacement = targetVscode.window.createTerminal({
    ...buildAttachTerminalOptions({
      host: resolved.hostId,
      project: resolved.project,
      session: resolved.session,
      distro: configValue(config, 'wslDistro', ''),
      wtmuxPath: wtmuxPathFromConfig(config)
    }),
    location: { parentTerminal: terminal }
  });
  try {
    const wasActive = targetVscode.window.activeTerminal === terminal;
    replacement.show(!wasActive);
    const processId = await replacement.processId;
    if (!Number.isSafeInteger(processId) || processId <= 0) {
      throw new Error('Replacement terminal did not start.');
    }
    terminal.dispose();
    return replacement;
  } catch (error) {
    replacement.dispose();
    throw error;
  }
}

async function inspectTerminalRestoration(terminals, state, deps = {}) {
  const config = deps.config || vscode.workspace.getConfiguration('wtmuxImagePaste');
  const runProcessImpl = deps.runProcess || runProcess;
  const active = new Set(terminals);
  if (state.handledNonces.size > 1024) {
    state.handledNonces.clear();
  }

  for (const terminal of terminals) {
    const stable = stableManagedTitle(terminal && terminal.name);
    if (stable) {
      await rememberTerminalBinding(terminal, stable, state, deps.now ? deps.now() : Date.now());
      continue;
    }
    const launchedTitle = state.launchedTerminalTitles.get(terminal);
    if (launchedTitle) {
      await rememberTerminalBinding(
        terminal,
        launchedTitle,
        state,
        deps.now ? deps.now() : Date.now()
      );
      continue;
    }
    if (deps.resolveLaunchedTerminal && managedLaunchTarget(terminal && terminal.creationOptions)) {
      try {
        const resolvedTitle = await deps.resolveLaunchedTerminal(terminal);
        if (resolvedTitle) {
          state.launchedTerminalTitles.set(terminal, resolvedTitle);
          await rememberTerminalBinding(
            terminal,
            resolvedTitle,
            state,
            deps.now ? deps.now() : Date.now()
          );
          continue;
        }
      } catch (error) {
        if (deps.onError) {
          deps.onError(error);
        }
      }
    }
    const recoveredTitle = await recoverTerminalBinding(terminal, state);
    const nonce = restoreNonce(terminal && terminal.name);
    if (
      recoveredTitle
      && !nonce
      && deps.replaceRevivedTerminal
      && !state.replacingTerminals.has(terminal)
    ) {
      state.replacingTerminals.add(terminal);
      try {
        await deps.replaceRevivedTerminal(terminal, recoveredTitle);
      } catch (error) {
        if (deps.onError) {
          deps.onError(error);
        }
      }
      continue;
    }
    if (!nonce || state.handledNonces.has(nonce)) {
      continue;
    }
    state.handledNonces.add(nonce);
    const previousTitle = state.lastManagedTitle.get(terminal) || '';
    const invocation = buildRestoreResponseInvocation(nonce, previousTitle, config);
    try {
      await runProcessImpl(invocation.command, invocation.args, invocation.options);
    } catch (error) {
      if (deps.onError) {
        deps.onError(error);
      }
    }
  }

  let bindingsChanged = false;
  for (const terminal of state.knownTerminals) {
    if (!active.has(terminal)) {
      state.lastManagedTitle.delete(terminal);
      const processId = state.terminalProcessIds.get(terminal);
      if (processId) {
        bindingsChanged = state.persistedProcessBindings.delete(processId) || bindingsChanged;
      }
      state.terminalProcessIds.delete(terminal);
      state.launchedTerminalTitles.delete(terminal);
      state.replacingTerminals.delete(terminal);
      state.knownTerminals.delete(terminal);
    }
  }
  for (const terminal of active) {
    state.knownTerminals.add(terminal);
  }
  if (bindingsChanged && state.persist) {
    await state.persist();
  }
}

function startTerminalRestoration(context, deps = {}) {
  const targetVscode = deps.vscode || vscode;
  const setIntervalImpl = deps.setInterval || setInterval;
  const clearIntervalImpl = deps.clearInterval || clearInterval;
  const storage = context.workspaceState || context.globalState;
  const persistedProcessBindings = loadTerminalProcessBindings(storage);
  let pendingPersistence = Promise.resolve();
  const state = {
    lastManagedTitle: new Map(),
    handledNonces: new Set(),
    knownTerminals: new Set(),
    launchedTerminalTitles: new Map(),
    replacingTerminals: new Set(),
    terminalProcessIds: new Map(),
    persistedProcessBindings,
    persist() {
      if (!storage || typeof storage.update !== 'function') {
        return Promise.resolve();
      }
      const payload = serializedTerminalProcessBindings(persistedProcessBindings);
      pendingPersistence = pendingPersistence
        .catch(() => {})
        .then(() => storage.update(TERMINAL_BINDINGS_KEY, payload));
      return pendingPersistence;
    }
  };
  let inspecting = false;

  const inspect = async () => {
    if (inspecting) {
      return;
    }
    inspecting = true;
    try {
      await inspectTerminalRestoration(targetVscode.window.terminals || [], state, {
        config: targetVscode.workspace.getConfiguration('wtmuxImagePaste'),
        runProcess: deps.runProcess || runProcess,
        resolveLaunchedTerminal: terminal => resolveManagedLaunchTitle(terminal, {
          config: targetVscode.workspace.getConfiguration('wtmuxImagePaste'),
          runProcess: deps.runProcess || runProcess
        }),
        replaceRevivedTerminal: (terminal, title) => replaceRevivedManagedTerminal(
          terminal,
          title,
          {
            vscode: targetVscode,
            config: targetVscode.workspace.getConfiguration('wtmuxImagePaste'),
            runProcess: deps.runProcess || runProcess
          }
        ),
        onError: deps.onError
      });
    } finally {
      inspecting = false;
    }
  };

  inspect();
  const interval = setIntervalImpl(inspect, RESTORE_POLL_MS);
  const disposable = {
    dispose() {
      clearIntervalImpl(interval);
      state.lastManagedTitle.clear();
      state.handledNonces.clear();
      state.knownTerminals.clear();
      state.launchedTerminalTitles.clear();
      state.replacingTerminals.clear();
      state.terminalProcessIds.clear();
      state.persistedProcessBindings.clear();
    }
  };
  context.subscriptions.push(disposable);
  if (typeof targetVscode.window.onDidOpenTerminal === 'function') {
    context.subscriptions.push(targetVscode.window.onDidOpenTerminal(inspect));
  }
  if (typeof targetVscode.window.onDidCloseTerminal === 'function') {
    context.subscriptions.push(targetVscode.window.onDidCloseTerminal(inspect));
  }
  return { state, inspect, disposable };
}

function quoteForBash(value) {
  return `'${String(value).replace(/'/g, `'\\''`)}'`;
}

function runProcessBinaryToFile(command, args, outputPath) {
  return new Promise((resolve, reject) => {
    const child = childProcess.spawn(command, args, {
      env: process.env,
      windowsHide: true
    });
    const stdoutChunks = [];
    let stderr = '';

    if (child.stdout) {
      child.stdout.on('data', chunk => {
        stdoutChunks.push(Buffer.from(chunk));
      });
    }
    if (child.stderr) {
      child.stderr.on('data', chunk => {
        stderr += chunk.toString();
      });
    }
    child.on('error', error => {
      reject(error);
    });
    child.on('close', async code => {
      if (code !== 0) {
        reject(new Error(stderr.trim() || `${command} exited with status ${code}`));
        return;
      }
      try {
        await fs.promises.writeFile(outputPath, Buffer.concat(stdoutChunks), { flag: 'wx' });
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  });
}

async function createTempImagePath(extension) {
  const dir = path.join(os.tmpdir(), 'wtmux-image-paste');
  await fs.promises.mkdir(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  return path.join(dir, `clipboard-${stamp}.${extension}`);
}

async function captureWindowsClipboardImage(outputPath) {
  const script = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$image = [System.Windows.Forms.Clipboard]::GetImage()
if ($null -eq $image) {
  Write-Error 'Clipboard does not contain an image.'
  exit 2
}
$image.Save($env:WTMUX_IMAGE_OUT_PATH, [System.Drawing.Imaging.ImageFormat]::Png)
`;
  await runProcess('powershell.exe', ['-NoProfile', '-STA', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], {
    env: { ...process.env, WTMUX_IMAGE_OUT_PATH: outputPath }
  });
}

async function captureLinuxClipboardImage(outputPath) {
  const attempts = [
    ['wl-paste', ['--type', 'image/png']],
    ['xclip', ['-selection', 'clipboard', '-t', 'image/png', '-o']]
  ];
  const errors = [];

  for (const [command, args] of attempts) {
    try {
      await runProcessBinaryToFile(command, args, outputPath);
      return;
    } catch (error) {
      errors.push(`${command}: ${conciseError(error)}`);
    }
  }

  throw new Error(`Clipboard image capture requires wl-paste or xclip. ${errors.join('; ')}`);
}

async function captureClipboardImage() {
  const outputPath = await createTempImagePath('png');

  if (process.platform === 'win32') {
    await captureWindowsClipboardImage(outputPath);
    return outputPath;
  }

  if (process.platform === 'darwin') {
    await runProcess('pngpaste', [outputPath]);
    return outputPath;
  }

  await captureLinuxClipboardImage(outputPath);
  return outputPath;
}

function parseHostPath(stdout) {
  const lines = stdout.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const pathLine = lines.find(line => line.startsWith('.wtmux/images/'));
  if (!pathLine) {
    throw new Error(`wtmux did not return a host image path: ${stdout.trim()}`);
  }
  return pathLine;
}

async function sendImageToHost(imagePath, deps = {}) {
  const config = deps.config || vscode.workspace.getConfiguration('wtmuxImagePaste');
  const platform = deps.platform || process.platform;
  const runProcessImpl = deps.runProcess || runProcess;
  const wtmuxPath = wtmuxPathFromConfig(config);
  const sourcePath = await sourcePathForWtmux(imagePath, { ...deps, config, platform, runProcess: runProcessImpl });
  const invocation = buildWtmuxImageSendInvocation(wtmuxPath, sourcePath, config, platform);
  const result = await runProcessImpl(invocation.command, invocation.args, invocation.options);
  return parseHostPath(result.stdout);
}

async function sourcePathForWtmux(imagePath, deps = {}) {
  const config = deps.config || vscode.workspace.getConfiguration('wtmuxImagePaste');
  const platform = deps.platform || process.platform;
  const runProcessImpl = deps.runProcess || runProcess;
  const runInWsl = configValue(config, 'runWtmuxInWslOnWindows', true);
  const shouldConvert = runInWsl || configValue(config, 'convertWindowsPathForWsl', true);
  const distro = configValue(config, 'wslDistro', '');

  if (platform !== 'win32' || !shouldConvert) {
    return imagePath;
  }

  const args = wslBaseArgs(distro);
  args.push('--', 'wslpath', '-a', imagePath);
  const result = await runProcessImpl('wsl.exe', args);
  const converted = result.stdout.trim().split(/\r?\n/).find(Boolean);
  if (!converted) {
    throw new Error('wslpath did not return a converted image path');
  }
  return converted;
}

function buildWtmuxImageSendInvocation(wtmuxPath, sourcePath, config, platform) {
  const runInWsl = configValue(config, 'runWtmuxInWslOnWindows', true);
  const distro = configValue(config, 'wslDistro', '');

  if (platform === 'win32' && runInWsl) {
    const bashCommand = `${quoteForBash(wtmuxPath)} image send ${quoteForBash(sourcePath)}`;
    return {
      command: 'wsl.exe',
      args: [...wslBaseArgs(distro), '--', 'bash', '-lc', bashCommand],
      options: { shell: false }
    };
  }

  return {
    command: wtmuxPath,
    args: ['image', 'send', sourcePath],
    options: { shell: platform === 'win32' }
  };
}

async function insertPathOrFallback(hostPath, deps = {}) {
  const targetVscode = deps.vscode || vscode;
  const config = deps.config || targetVscode.workspace.getConfiguration('wtmuxImagePaste');
  const shouldInsert = configValue(config, 'insertIntoTerminal', true);
  const terminal = Object.prototype.hasOwnProperty.call(deps, 'terminal')
    ? deps.terminal
    : targetVscode.window.activeTerminal;

  if (shouldInsert && terminal) {
    terminal.sendText(hostPath, false);
    return 'inserted';
  }

  await targetVscode.env.clipboard.writeText(hostPath);
  return 'copied';
}

function conciseError(error) {
  const message = error && error.message ? error.message : String(error);
  return message.split(/\r?\n/).find(Boolean) || 'Unknown error';
}

async function pasteImageToHost() {
  let tempImagePath = '';
  try {
    tempImagePath = await captureClipboardImage();
    const hostPath = await sendImageToHost(tempImagePath);
    const delivery = await insertPathOrFallback(hostPath);
    const config = vscode.workspace.getConfiguration('wtmuxImagePaste');

    if (config.get('showSuccessNotification', true)) {
      if (delivery === 'inserted') {
        vscode.window.showInformationMessage(`Sent image to wtmux: ${hostPath}`);
      } else {
        vscode.window.showInformationMessage(`Sent image to wtmux and copied path: ${hostPath}`);
      }
    }
  } catch (error) {
    vscode.window.showErrorMessage(`wtmux image paste failed: ${conciseError(error)}`);
  } finally {
    if (tempImagePath) {
      fs.promises.rm(tempImagePath, { force: true }).catch(() => {});
    }
  }
}

function parseOpenUri(uri) {
  if (!uri || uri.authority !== 'wtmux.wtmux-image-paste' || uri.path !== '/open') {
    throw new Error('Unsupported wtmux URI.');
  }
  const query = new URLSearchParams(uri.query || '');
  const host = query.get('host') || '';
  const project = query.get('project') || '';
  const session = query.get('session') || '';
  const distro = query.get('distro') || '';
  if (!/^[A-Za-z0-9._:-]{1,160}$/.test(host) || !/^[A-Za-z0-9._-]{1,128}$/.test(session)) {
    throw new Error('wtmux host or session identity is invalid.');
  }
  if (!project || project.length > 256 || /[\u0000-\u001f\u007f]/.test(project)) {
    throw new Error('wtmux project is invalid.');
  }
  if (!distro || distro.length > 64 || /[\u0000-\u001f\u007f]/.test(distro)) {
    throw new Error('WSL distribution is invalid.');
  }
  return { host, project, session, distro };
}

function buildAttachTerminalOptions(target) {
  return {
    shellPath: 'wsl.exe',
    shellArgs: [
      ...wslBaseArgs(target.distro), '--cd', '~', '--',
      target.wtmuxPath || '.local/bin/wtmux', 'vscode', 'terminal',
      '--host', target.host, '--project', target.project, '--session', target.session
    ]
  };
}

async function openWtmuxUri(uri) {
  try {
    const target = parseOpenUri(uri);
    const terminal = vscode.window.createTerminal(buildAttachTerminalOptions(target));
    terminal.show();
  } catch (error) {
    vscode.window.showErrorMessage(`wtmux open failed: ${conciseError(error)}`);
  }
}

async function migrateLegacyTerminal() {
  const terminals = (vscode.window.terminals || [])
    .map(terminal => ({ terminal, legacyTitle: legacyManagedTitle(terminal.name) }))
    .filter(item => item.legacyTitle);
  if (!terminals.length) {
    vscode.window.showInformationMessage('No legacy wtmux terminals are open.');
    return;
  }
  const items = terminals.map(item => ({
    label: item.terminal.name,
    description: 'Open a managed replacement',
    target: item
  }));
  const selected = typeof vscode.window.showQuickPick === 'function'
    ? await vscode.window.showQuickPick(items, { placeHolder: 'Choose a legacy wtmux terminal to migrate' })
    : items[0];
  if (!selected) {
    return;
  }

  try {
    const config = vscode.workspace.getConfiguration('wtmuxImagePaste');
    const invocation = buildResolveTitleInvocation(selected.target.terminal.name, config);
    const result = await runProcess(invocation.command, invocation.args, invocation.options);
    const resolved = JSON.parse(result.stdout);
    if (
      resolved.status !== 'resolved'
      || !resolved.hostId
      || !resolved.project
      || !resolved.session
    ) {
      throw new Error('The legacy title does not resolve to one live session.');
    }
    const distro = configValue(config, 'wslDistro', '');
    const replacement = vscode.window.createTerminal(buildAttachTerminalOptions({
      host: resolved.hostId,
      project: resolved.project,
      session: resolved.session,
      distro
    }));
    replacement.show();
  } catch (error) {
    vscode.window.showErrorMessage(`wtmux terminal migration failed: ${conciseError(error)}`);
  }
}

async function offerLegacyMigration(context) {
  if (!context.globalState || !context.extension || !context.extension.packageJSON) {
    return;
  }
  const version = context.extension.packageJSON.version;
  if (context.globalState.get(MIGRATION_NOTICE_KEY) === version) {
    return;
  }
  await context.globalState.update(MIGRATION_NOTICE_KEY, version);
  const hasLegacy = (vscode.window.terminals || []).some(terminal => legacyManagedTitle(terminal.name));
  if (!hasLegacy) {
    return;
  }
  const action = 'Migrate Terminal';
  const selected = await vscode.window.showInformationMessage(
    'Legacy wtmux terminals can be migrated to reliable VS Code restoration.',
    action
  );
  if (selected === action) {
    await vscode.commands.executeCommand('wtmux.migrateLegacyTerminal');
  }
}

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand('wtmux.pasteImageToHost', pasteImageToHost),
    vscode.commands.registerCommand('wtmux.migrateLegacyTerminal', migrateLegacyTerminal),
    vscode.window.registerUriHandler({ handleUri: openWtmuxUri })
  );
  startTerminalRestoration(context);
  offerLegacyMigration(context).catch(error => {
    vscode.window.showErrorMessage(`wtmux migration check failed: ${conciseError(error)}`);
  });
}

function deactivate() {}

module.exports = {
  activate,
  deactivate,
  _test: {
    buildWtmuxImageSendInvocation,
    buildResolveTitleInvocation,
    buildResolveTargetInvocation,
    buildRestoreResponseInvocation,
    buildWslWtmuxInvocation,
    captureLinuxClipboardImage,
    buildAttachTerminalOptions,
    inspectTerminalRestoration,
    legacyManagedTitle,
    loadTerminalProcessBindings,
    managedLaunchTarget,
    parseOpenUri,
    configValue,
    insertPathOrFallback,
    parseHostPath,
    quoteForBash,
    restoreNonce,
    replaceRevivedManagedTerminal,
    resolveManagedLaunchTitle,
    serializedTerminalProcessBindings,
    sourcePathForWtmux,
    sendImageToHost,
    stableManagedTitle,
    startTerminalRestoration,
    wslBaseArgs
  }
};
